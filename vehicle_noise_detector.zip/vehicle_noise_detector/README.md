# Vehicle Noise Detector

Binary classifier that detects abnormal vehicle sounds (IP noise, cracking, steering vibration, etc.) from raw audio recordings.

---

## Project structure

```
vehicle_noise_detector/
├── config.py               ← All hyperparameters — edit this to tune
├── train.py                ← K-Fold training script
├── predict.py              ← Inference on new audio files
├── analyze.py              ← Visualize and compare audio files
├── requirements.txt
├── data/
│   ├── ok/                 ← Place OK vehicle .wav files here
│   └── notok/              ← Place Not-OK vehicle .wav files here
├── models/                 ← Saved checkpoints (auto-created)
├── outputs/                ← Charts, logs, predictions (auto-created)
└── src/
    ├── audio_utils.py      ← Audio loading, speech removal, windowing
    ├── features.py         ← Mel spectrogram extraction + SpecAugment
    ├── dataset.py          ← Dataset builder + PyTorch Dataset class
    └── model.py            ← VehicleNoiseNet CNN architecture
```

---

## Setup

### Windows
```bat
:: Double-click install.bat  OR run in Command Prompt:
install.bat
```

### Mac / Linux
```bash
chmod +x install.sh && ./install.sh
```

### Manual (any platform)
```bash
# Step 1 — core packages
pip install numpy scikit-learn matplotlib soundfile seaborn tqdm pandas

# Step 2 — PyTorch CPU build (works on all platforms including Windows)
pip install torch torchaudio --index-url https://download.pytorch.org/whl/cpu

# NOTE: Do NOT run pip install -r requirements.txt directly on Windows.
# audiomentations pulls in numpy-rms/numpy-minmax which fail to build on Windows.
# This project does NOT need audiomentations — speech removal and augmentation
# are built-in using pure NumPy.
```

### Add your audio files
```
data/ok/        ← Copy all OK vehicle .wav files here
data/notok/     ← Copy all Not-OK vehicle .wav files here
```

---

## How it works

### Speech removal
Human speech in recordings is automatically detected and replaced with
low-amplitude noise before any feature extraction. This prevents the model
from accidentally learning speech patterns as a proxy for "noise".

The VAD (Voice Activity Detection) is energy-based:
- Frames above -20 dBFS → treated as speech → replaced with ~0.002 amplitude noise
- Full windows above -15 dBFS → skipped (too speech-heavy to be useful)

### Feature extraction
Each long recording is sliced into 3-second overlapping windows (1s hop).
Each window is converted to a 128-band Mel spectrogram focused on **300 Hz – 10 kHz**.

Why 300 Hz minimum? Analysis of your files showed that the 20–300 Hz band
(engine rumble, road noise) is nearly identical between OK and Not-OK vehicles.
Excluding it forces the model to focus on the 2–8 kHz range where cracking and
IP noise are clearly different.

### Data augmentation
Each training window is augmented 20× using:
- SpecAugment: random time and frequency masking
- Random amplitude scaling (±20%)

This expands 40 files → ~3,000–5,000 training windows.

### Model
Lightweight 3-block CNN (~470K parameters) with:
- Tall kernels (7×3) in block 1 to capture frequency band patterns
- AdaptiveAvgPool to handle variable-length inputs
- K-Fold cross validation (k=5) to get reliable accuracy estimates from small data

### Inference
For a new audio file, the model scores every 3-second window independently.
The final verdict uses majority voting: if ≥35% of windows are classified as
Not-OK, the whole file is flagged as Not-OK.

---

## Usage

### Step 1 — Analyze your audio (optional but recommended)
```bash
python analyze.py
# Uses files from data/ok/ and data/notok/ automatically

# Or specify files directly:
python analyze.py --ok data/ok/file1.wav --notok data/notok/file2.wav
```
Saves a chart to `outputs/audio_analysis.png`.

### Step 2 — Train the model
```bash
python train.py
```
This will:
- Process all files in `data/ok/` and `data/notok/`
- Remove speech from each file
- Extract mel spectrogram features with augmentation
- Run 5-fold cross validation
- Save the best model to `models/best_model.pt`
- Save training curves and confusion matrices to `outputs/`

### Step 3 — Predict on new files
```bash
# Single file
python predict.py path/to/new_vehicle.wav

# Multiple files at once
python predict.py vehicle1.wav vehicle2.wav vehicle3.wav

# Use a specific model checkpoint
python predict.py vehicle.wav --model models/best_fold3.pt

# Adjust sensitivity (lower vote threshold = more sensitive to noise)
python predict.py vehicle.wav --vote 0.25
```

---

## Tuning guide

Edit `config.py` to adjust behaviour:

| Parameter | Default | Effect |
|---|---|---|
| `WINDOW_SEC` | 3.0 | Longer windows = more context but fewer samples |
| `AUG_MULTIPLIER` | 20 | Increase if dataset is very small |
| `F_MIN` | 300 | Lower to include more low-frequency content |
| `VOTE_THRESHOLD` | 0.35 | Lower = more sensitive (more Not-OK detections) |
| `INFERENCE_THRESHOLD` | 0.50 | Per-window classification threshold |
| `SPEECH_ENERGY_THRESHOLD` | -20 | Lower = more aggressive speech removal |
| `K_FOLDS` | 5 | Reduce to 3 if dataset is very small |
| `PATIENCE` | 10 | Increase for more training epochs before early stop |

---

## Adding more noise types

To detect specific noise types (IP noise vs cracking vs steering vibration)
instead of just OK/Not-OK, change the labels in `src/dataset.py`:

```python
# Current (binary)
label = 0   # OK
label = 1   # Not-OK

# Multi-class (add more categories)
# label = 0   # OK
# label = 1   # IP noise
# label = 2   # Cracking
# label = 3   # Steering vibration
```

Then change the model output from `nn.Linear(128, 1)` to `nn.Linear(128, N_CLASSES)`
and switch from `BCEWithLogitsLoss` to `CrossEntropyLoss` in `train.py`.

---

## Requirements

- Python 3.10+
- PyTorch 2.0+
- No GPU required (trains in ~5–10 min on CPU with 40 files)
