# analyze.py — Visualize and compare audio files before training

import os
import sys
import argparse
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import SAMPLE_RATE, N_FFT, HOP_LENGTH, N_MELS, F_MIN, F_MAX, OUTPUTS_DIR, OK_DIR, NOTOK_DIR
from src.audio_utils import load_wav, remove_speech_energy_vad, rms_db
from src.features import audio_to_melspec, build_mel_filterbank

os.makedirs(OUTPUTS_DIR, exist_ok=True)
BG = '#0d0d1a'


def band_energy(audio, sr, fmin, fmax):
    spec  = np.abs(np.fft.rfft(audio * np.hanning(len(audio)))) ** 2
    freqs = np.fft.rfftfreq(len(audio), 1 / sr)
    mask  = (freqs >= fmin) & (freqs <= fmax)
    return float(10 * np.log10(np.mean(spec[mask]) + 1e-9))


def smooth(x, w=200):
    return np.convolve(x, np.ones(w) / w, mode='valid')


def analyze_file(path, label="", color='#00a8ff', ax_wave=None, ax_mel=None,
                 ax_spec=None, ax_bands=None):
    audio, sr = load_wav(path, SAMPLE_RATE)
    clean, speech_pct = remove_speech_energy_vad(audio, sr)
    dur = len(audio) / sr
    seg = clean[:sr * 30]

    print(f"\n  {label} -- {os.path.basename(path)}")
    print(f"    Duration   : {dur:.1f}s")
    print(f"    RMS        : {rms_db(audio):.1f} dBFS")
    print(f"    Speech     : {speech_pct:.1f}%")
    print(f"    20-300Hz   : {band_energy(seg, sr, 20, 300):.1f} dB")
    print(f"    300-2kHz   : {band_energy(seg, sr, 300, 2000):.1f} dB")
    print(f"    2-8kHz     : {band_energy(seg, sr, 2000, 8000):.1f} dB")
    print(f"    8-20kHz    : {band_energy(seg, sr, 8000, 20000):.1f} dB")

    if ax_wave:
        t = np.linspace(0, dur, len(audio))
        ax_wave.plot(t[::200], audio[::200], color=color, linewidth=0.4, alpha=0.8)
        ax_wave.set_facecolor(BG)
        ax_wave.set_title(f"{label}\n{os.path.basename(path)}", color=color,
                          fontsize=8, fontweight='bold')
        ax_wave.set_xlabel('Time (s)', color='#888', fontsize=7)
        ax_wave.tick_params(colors='#666', labelsize=6)
        for sp in ax_wave.spines.values(): sp.set_color('#333')

    if ax_mel:
        mel = audio_to_melspec(seg, sr)
        ax_mel.imshow(mel, aspect='auto', origin='lower',
                      extent=[0, 30, 0, N_MELS],
                      cmap='magma', vmin=-3, vmax=3)
        ax_mel.set_facecolor(BG)
        ax_mel.set_title('Mel spectrogram (30s)', color='#aaa', fontsize=8)
        ax_mel.set_xlabel('Time (s)', color='#888', fontsize=7)
        ax_mel.set_ylabel('Mel band', color='#888', fontsize=7)
        ax_mel.tick_params(colors='#666', labelsize=6)
        for sp in ax_mel.spines.values(): sp.set_color('#333')

    if ax_spec:
        spec = np.abs(np.fft.rfft(seg * np.hanning(len(seg)))) ** 2
        freqs = np.fft.rfftfreq(len(seg), 1 / sr)
        db_raw = 10 * np.log10(spec + 1e-9)
        db_sm  = smooth(db_raw)
        f_sm   = freqs[:len(db_sm)]
        ax_spec.plot(f_sm, db_sm, color=color, linewidth=1.0, label=label)
        ax_spec.set_facecolor(BG)
        ax_spec.set_xlim(0, 10000)
        ax_spec.tick_params(colors='#666', labelsize=6)
        for sp in ax_spec.spines.values(): sp.set_color('#333')

    return {
        'label': label, 'color': color,
        'bands': [
            band_energy(seg, sr, 20,   300),
            band_energy(seg, sr, 300,  2000),
            band_energy(seg, sr, 2000, 8000),
            band_energy(seg, sr, 8000, 20000),
        ]
    }


def run_analysis(ok_files: list, notok_files: list):
    all_files = [(f, 'OK', '#00c896') for f in ok_files] + \
                [(f, 'Not-OK', '#ff6b6b') for f in notok_files]
    n = len(all_files)

    if n == 0:
        print("\n  No files to analyze.")
        return

    print(f"\n{'='*60}")
    print(" AUDIO ANALYSIS")
    print(f"{'='*60}")

    fig = plt.figure(figsize=(6 * n, 14), facecolor='#0f0f1a')
    fig.suptitle('Vehicle Audio Analysis -- OK vs Not-OK',
                 color='white', fontsize=13, fontweight='bold')

    band_data = []
    for i, (path, label, color) in enumerate(all_files):
        ax_wave = fig.add_subplot(4, n, i + 1)
        ax_mel  = fig.add_subplot(4, n, i + 1 + n)
        ax_spec = fig.add_subplot(4, n, i + 1 + 2*n)
        r = analyze_file(path, label, color, ax_wave, ax_mel, ax_spec)
        band_data.append(r)

    ax_bar = fig.add_subplot(4, 1, 4)
    band_labels = ['20-300 Hz\n(rumble)', '300-2k Hz\n(IP/speech)',
                   '2-8k Hz\n(cracking)', '8-20k Hz\n(hiss)']
    x = np.arange(4)
    w = 0.8 / n
    for i, r in enumerate(band_data):
        offset = (i - n / 2 + 0.5) * w
        ax_bar.bar(x + offset, r['bands'], w, label=r['label'],
                   color=r['color'], alpha=0.85)

    ax_bar.set_facecolor(BG)
    ax_bar.set_xticks(x)
    ax_bar.set_xticklabels(band_labels, color='#aaa', fontsize=9)
    ax_bar.set_ylabel('Mean power (dB)', color='#aaa', fontsize=9)
    ax_bar.set_title('Band energy comparison', color='white', fontsize=10, fontweight='bold')
    ax_bar.legend(fontsize=8, facecolor='#1a1a2e', labelcolor='white', ncol=n)
    ax_bar.tick_params(colors='#666', labelsize=8)
    for sp in ax_bar.spines.values(): sp.set_color('#333')

    out = os.path.join(OUTPUTS_DIR, 'audio_analysis.png')
    plt.tight_layout()
    plt.savefig(out, dpi=130, bbox_inches='tight', facecolor='#0f0f1a')
    plt.close()
    print(f"\nAnalysis chart saved -> {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Analyze vehicle audio files")
    parser.add_argument("--ok",    nargs='+', default=[], help="OK audio files")
    parser.add_argument("--notok", nargs='+', default=[], help="Not-OK audio files")
    args = parser.parse_args()

    if not args.ok and not args.notok:
        from src.dataset import collect_audio_files

        os.makedirs(OK_DIR,    exist_ok=True)
        os.makedirs(NOTOK_DIR, exist_ok=True)

        ok_files    = collect_audio_files(OK_DIR)[:3]
        notok_files = collect_audio_files(NOTOK_DIR)[:3]

        if not ok_files and not notok_files:
            print("\n  No audio files found.")
            print(f"  Copy your OK .wav files into:     {OK_DIR}")
            print(f"  Copy your Not-OK .wav files into: {NOTOK_DIR}")
            print("\n  Then run:  python analyze.py")
            sys.exit(0)

        if not ok_files:
            print(f"\n  [WARN] No OK files found in {OK_DIR}")
        if not notok_files:
            print(f"\n  [WARN] No Not-OK files found in {NOTOK_DIR}")
    else:
        ok_files    = args.ok
        notok_files = args.notok

    run_analysis(ok_files, notok_files)
