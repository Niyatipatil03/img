@echo off
echo ================================================
echo  Vehicle Noise Detector - Windows Setup
echo ================================================

echo.
echo Step 1: Installing core dependencies...
pip install numpy scikit-learn matplotlib soundfile seaborn tqdm pandas
if %errorlevel% neq 0 (
    echo ERROR: Core install failed. Make sure Python and pip are working.
    pause
    exit /b 1
)

echo.
echo Step 2: Installing PyTorch (CPU version)...
echo (For GPU support visit https://pytorch.org and get the CUDA version)
pip install torch torchaudio --index-url https://download.pytorch.org/whl/cpu
if %errorlevel% neq 0 (
    echo ERROR: PyTorch install failed.
    pause
    exit /b 1
)

echo.
echo Step 3: Verifying installation...
python -c "import torch; import numpy; import sklearn; import matplotlib; import soundfile; print('All packages OK. PyTorch version:', torch.__version__)"
if %errorlevel% neq 0 (
    echo ERROR: Verification failed - some package did not install correctly.
    pause
    exit /b 1
)

echo.
echo ================================================
echo  Setup complete!
echo.
echo  Next steps:
echo    1. Copy OK vehicle .wav files to:     data\ok\
echo    2. Copy Not-OK vehicle .wav files to: data\notok\
echo    3. Run:  python analyze.py
echo    4. Run:  python train.py
echo    5. Run:  python predict.py your_file.wav
echo ================================================
pause
