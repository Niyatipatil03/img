# config.py — Central configuration for Vehicle Noise Detector
# Edit this file to tune hyperparameters without touching any other code.

import os

# ── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
DATA_DIR    = os.path.join(BASE_DIR, "data")
OK_DIR      = os.path.join(DATA_DIR, "OK")
NOTOK_DIR   = os.path.join(DATA_DIR, "NOT OK")
MODELS_DIR  = os.path.join(BASE_DIR, "models")
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs")

# ── Audio ────────────────────────────────────────────────────────────────────
SAMPLE_RATE     = 22050     # All audio resampled to this
WINDOW_SEC      = 3.0       # Length of each training window in seconds
HOP_SEC         = 1.0       # Hop between windows (overlap = WINDOW_SEC - HOP_SEC)
MIN_DURATION    = 1.0       # Minimum window duration to keep (seconds)

# ── Speech removal ───────────────────────────────────────────────────────────
# Energy-based VAD thresholds (dBFS)
SPEECH_ENERGY_THRESHOLD  = -20.0   # Frames above this = likely speech → mute
SILENCE_THRESHOLD        = -50.0   # Frames below this = silence → skip window
WINDOW_SKIP_THRESHOLD    = -15.0   # Full window above this = speech-heavy → skip
SPEECH_REPLACEMENT_AMP   = 0.002   # Amplitude of noise used to replace speech

# ── Feature extraction ───────────────────────────────────────────────────────
N_FFT       = 2048
HOP_LENGTH  = 512
N_MELS      = 128
F_MIN       = 300      # Ignore low rumble (engine/road) below 300 Hz
F_MAX       = 10000    # Focus on 300 Hz – 10 kHz (where noise lives)
TARGET_FRAMES = 128    # Fixed time dimension for model input

# ── Augmentation ─────────────────────────────────────────────────────────────
AUGMENT         = True
AUG_MULTIPLIER  = 20      # How many augmented versions per original window
GAUSSIAN_NOISE_MIN  = 0.001
GAUSSIAN_NOISE_MAX  = 0.010
TIME_STRETCH_MIN    = 0.85
TIME_STRETCH_MAX    = 1.15
PITCH_SHIFT_MIN     = -2
PITCH_SHIFT_MAX     = 2
SHIFT_MIN           = -0.15
SHIFT_MAX           = 0.15
TIME_MASK_RATIO     = 0.10   # Mask up to 10% of time frames
FREQ_MASK_RATIO     = 0.10   # Mask up to 10% of mel bands

# ── Model ────────────────────────────────────────────────────────────────────
DROPOUT_CONV        = 0.25
DROPOUT_FC          = 0.40
HIDDEN_DIM          = 128

# ── Training ─────────────────────────────────────────────────────────────────
K_FOLDS         = 5
EPOCHS          = 50
BATCH_SIZE      = 32
LEARNING_RATE   = 3e-4
WEIGHT_DECAY    = 1e-3
PATIENCE        = 10          # Early stopping patience
POS_WEIGHT      = 1.5         # BCEWithLogitsLoss weight for Not-OK class
RANDOM_SEED     = 42

# ── Inference ────────────────────────────────────────────────────────────────
INFERENCE_THRESHOLD = 0.50    # Probability threshold for Not-OK decision
# Voting: fraction of windows that must be Not-OK to flag whole file
VOTE_THRESHOLD      = 0.35
