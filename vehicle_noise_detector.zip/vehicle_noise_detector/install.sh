#!/bin/bash
echo "================================================"
echo " Vehicle Noise Detector - Mac/Linux Setup"
echo "================================================"

echo ""
echo "Step 1: Installing core dependencies..."
pip install numpy scikit-learn matplotlib soundfile seaborn tqdm pandas
if [ $? -ne 0 ]; then
    echo "ERROR: Core install failed."
    exit 1
fi

echo ""
echo "Step 2: Installing PyTorch..."
pip install torch torchaudio
if [ $? -ne 0 ]; then
    echo "ERROR: PyTorch install failed."
    exit 1
fi

echo ""
echo "Step 3: Verifying..."
python3 -c "import torch; import numpy; import sklearn; import matplotlib; import soundfile; print('All packages OK. PyTorch:', torch.__version__)"

echo ""
echo "================================================"
echo " Setup complete!"
echo ""
echo " Next steps:"
echo "   1. Copy OK .wav files to:     data/ok/"
echo "   2. Copy Not-OK .wav files to: data/notok/"
echo "   3. python3 analyze.py"
echo "   4. python3 train.py"
echo "   5. python3 predict.py your_file.wav"
echo "================================================"
