# src/model.py — VehicleNoiseNet architecture

import torch
import torch.nn as nn
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DROPOUT_CONV, DROPOUT_FC, HIDDEN_DIM, N_MELS, TARGET_FRAMES


class ConvBlock(nn.Module):
    """Conv2d → BatchNorm → ReLU → optional MaxPool → Dropout."""
    def __init__(self, in_ch, out_ch, kernel, padding, pool=True, dropout=DROPOUT_CONV):
        super().__init__()
        layers = [
            nn.Conv2d(in_ch, out_ch, kernel_size=kernel, padding=padding, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        ]
        if pool:
            layers.append(nn.MaxPool2d(2, 2))
        if dropout > 0:
            layers.append(nn.Dropout2d(dropout))
        self.block = nn.Sequential(*layers)

    def forward(self, x):
        return self.block(x)


class VehicleNoiseNet(nn.Module):
    """
    Lightweight CNN for vehicle noise binary classification.

    Input  : (batch, 1, N_MELS, TARGET_FRAMES)  →  (batch, 1, 128, 128)
    Output : (batch,) raw logits — apply sigmoid for probability

    Architecture rationale:
    - Tall kernels (7,3) in block 1 capture frequency patterns spanning
      multiple mel bands — good for detecting the 2-8 kHz energy burst
      that separates Not-OK from OK (confirmed by spectral analysis).
    - AdaptiveAvgPool ensures the model works regardless of input length
      variations (important when some windows are shorter than TARGET_FRAMES).
    - Small network (< 500K params) prevents overfitting on the small dataset.
    """

    def __init__(self):
        super().__init__()

        self.features = nn.Sequential(
            # Block 1 — tall kernel captures frequency band patterns
            ConvBlock(1,  32, kernel=(7, 3), padding=(3, 1), pool=True,  dropout=0.20),
            # Block 2 — temporal patterns within frequency bands
            ConvBlock(32, 64, kernel=(5, 3), padding=(2, 1), pool=True,  dropout=0.25),
            # Block 3 — higher-level combinations
            ConvBlock(64, 64, kernel=(3, 3), padding=(1, 1), pool=False, dropout=0.00),
            # Global pooling — fixed 4x4 output regardless of input size
            nn.AdaptiveAvgPool2d((4, 4)),
        )

        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 4 * 4, HIDDEN_DIM),
            nn.ReLU(inplace=True),
            nn.Dropout(DROPOUT_FC),
            nn.Linear(HIDDEN_DIM, 1)   # single logit for binary classification
        )

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                nn.init.constant_(m.bias, 0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.classifier(self.features(x)).squeeze(1)

    def predict_proba(self, x: torch.Tensor) -> torch.Tensor:
        """Return sigmoid probabilities (0=OK, 1=Not-OK)."""
        with torch.no_grad():
            return torch.sigmoid(self.forward(x))

    def count_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


if __name__ == "__main__":
    model = VehicleNoiseNet()
    dummy = torch.randn(4, 1, N_MELS, TARGET_FRAMES)
    out   = model(dummy)
    print(f"Output shape : {out.shape}")
    print(f"Parameters   : {model.count_parameters():,}")
    print("Model OK.")
