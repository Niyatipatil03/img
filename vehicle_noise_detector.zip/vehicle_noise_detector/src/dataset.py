# src/dataset.py — Build training dataset from raw audio files

import os
import sys
import numpy as np
import pickle
from tqdm import tqdm

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import (
    OK_DIR, NOTOK_DIR, OUTPUTS_DIR,
    SAMPLE_RATE, WINDOW_SEC, HOP_SEC,
    AUGMENT, AUG_MULTIPLIER,
    WINDOW_SKIP_THRESHOLD, SILENCE_THRESHOLD,
    RANDOM_SEED
)
from src.audio_utils import load_wav, remove_speech_energy_vad, slice_audio, is_valid_window
from src.features import extract_all_features

import torch
from torch.utils.data import Dataset


class VehicleNoiseDataset(Dataset):
    """
    PyTorch Dataset for vehicle noise classification.
    Each sample is a (1, N_MELS, TARGET_FRAMES) mel spectrogram tensor.
    Label: 0 = OK, 1 = Not-OK
    """
    def __init__(self, features: list, labels: list, augment: bool = False):
        self.augment = augment
        self.X = []
        self.y = torch.FloatTensor(labels)

        for feat in features:
            tensor = torch.FloatTensor(feat).unsqueeze(0)  # (1, n_mels, frames)
            self.X.append(tensor)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


def collect_audio_files(directory: str, extensions: tuple = ('.wav', '.mp3', '.m4a')) -> list:
    """Return all audio files in a directory."""
    files = []
    for fname in sorted(os.listdir(directory)):
        if fname.lower().endswith(extensions):
            files.append(os.path.join(directory, fname))
    return files


def process_file(
    path: str,
    label: int,
    augment: bool = False,
    aug_multiplier: int = 1,
    verbose: bool = True
) -> tuple[list, list]:
    """
    Full pipeline for one audio file:
      1. Load + resample
      2. Remove speech via energy VAD
      3. Slice into windows
      4. Filter invalid windows
      5. Extract mel spectrogram features
      6. Optionally augment

    Returns (features, labels) lists.
    """
    try:
        audio, sr = load_wav(path, SAMPLE_RATE)
    except Exception as e:
        print(f"  [ERROR] Could not load {os.path.basename(path)}: {e}")
        return [], []

    # Speech removal
    clean_audio, speech_pct = remove_speech_energy_vad(audio, sr)

    # Slice into windows
    all_windows = slice_audio(clean_audio, sr, WINDOW_SEC, HOP_SEC)

    # Filter windows
    valid_windows = [
        w for w in all_windows
        if is_valid_window(w, WINDOW_SKIP_THRESHOLD, SILENCE_THRESHOLD)
    ]

    if not valid_windows:
        print(f"  [WARN] No valid windows in {os.path.basename(path)}")
        return [], []

    # Extract features (with augmentation for training)
    features = extract_all_features(
        audio=clean_audio,
        sr=sr,
        windows=valid_windows,
        augment=augment,
        aug_multiplier=aug_multiplier
    )
    labels = [label] * len(features)

    if verbose:
        aug_str = f" → {len(features)} augmented" if augment else ""
        print(f"  {'OK    ' if label==0 else 'Not-OK'} | {os.path.basename(path):<45} "
              f"| {len(valid_windows)} windows{aug_str} | speech: {speech_pct:.1f}%")

    return features, labels


def build_full_dataset(
    ok_dir: str = OK_DIR,
    notok_dir: str = NOTOK_DIR,
    augment: bool = AUGMENT,
    aug_multiplier: int = AUG_MULTIPLIER,
    cache_path: str = None
) -> tuple[list, list]:
    """
    Process all OK and Not-OK files.
    Returns (all_features, all_labels).

    Optionally saves/loads from a cache file to avoid re-processing.
    """
    if cache_path and os.path.exists(cache_path):
        print(f"Loading cached dataset from {cache_path}")
        with open(cache_path, 'rb') as f:
            return pickle.load(f)

    np.random.seed(RANDOM_SEED)

    ok_files    = collect_audio_files(ok_dir)
    notok_files = collect_audio_files(notok_dir)

    print(f"\nFound {len(ok_files)} OK files and {len(notok_files)} Not-OK files")
    print("=" * 70)

    all_features, all_labels = [], []

    print("\nProcessing OK files...")
    for path in ok_files:
        feats, labs = process_file(path, label=0, augment=augment,
                                   aug_multiplier=aug_multiplier)
        all_features.extend(feats)
        all_labels.extend(labs)

    print("\nProcessing Not-OK files...")
    for path in notok_files:
        feats, labs = process_file(path, label=1, augment=augment,
                                   aug_multiplier=aug_multiplier)
        all_features.extend(feats)
        all_labels.extend(labs)

    ok_count    = sum(1 for l in all_labels if l == 0)
    notok_count = sum(1 for l in all_labels if l == 1)

    print(f"\n{'='*70}")
    print(f"Dataset ready: {len(all_features)} total windows")
    print(f"  OK     : {ok_count}")
    print(f"  Not-OK : {notok_count}")
    print(f"  Ratio  : {ok_count/(notok_count+1e-8):.2f}:1")

    if cache_path:
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)
        with open(cache_path, 'wb') as f:
            pickle.dump((all_features, all_labels), f)
        print(f"Dataset cached to {cache_path}")

    return all_features, all_labels
