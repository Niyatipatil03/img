# src/features.py — Mel spectrogram feature extraction

import numpy as np
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import (
    SAMPLE_RATE, N_FFT, HOP_LENGTH, N_MELS,
    F_MIN, F_MAX, TARGET_FRAMES,
    TIME_MASK_RATIO, FREQ_MASK_RATIO
)


def build_mel_filterbank(
    sr: int,
    n_fft: int,
    n_mels: int,
    fmin: float,
    fmax: float
) -> np.ndarray:
    """
    Build a triangular mel filterbank matrix.
    Shape: (n_mels, n_fft//2 + 1)

    We use fmin=300 Hz deliberately — this ignores engine rumble and road
    noise which are identical in OK and Not-OK vehicles (confirmed by analysis).
    The model focuses on 300 Hz – 10 kHz where cracking and IP noise live.
    """
    mel_min = 2595 * np.log10(1 + fmin / 700)
    mel_max = 2595 * np.log10(1 + fmax / 700)
    mel_points = np.linspace(mel_min, mel_max, n_mels + 2)
    hz_points  = 700 * (10 ** (mel_points / 2595) - 1)
    bin_points = np.floor((n_fft + 1) * hz_points / sr).astype(int)
    bin_points = np.clip(bin_points, 0, n_fft // 2)

    fb = np.zeros((n_mels, n_fft // 2 + 1), dtype=np.float32)
    for m in range(1, n_mels + 1):
        lo, mid, hi = bin_points[m-1], bin_points[m], bin_points[m+1]
        for k in range(lo, mid):
            fb[m-1, k] = (k - lo) / (mid - lo + 1e-8)
        for k in range(mid, hi):
            fb[m-1, k] = (hi - k) / (hi - mid + 1e-8)

    return fb


# Pre-build filterbank once (reused for every window)
_FILTERBANK = build_mel_filterbank(SAMPLE_RATE, N_FFT, N_MELS, F_MIN, F_MAX)


def audio_to_melspec(
    audio: np.ndarray,
    sr: int = SAMPLE_RATE,
    n_fft: int = N_FFT,
    hop: int = HOP_LENGTH,
    n_mels: int = N_MELS,
    normalize: bool = True
) -> np.ndarray:
    """
    Convert a raw audio window to a normalized Mel spectrogram.

    Returns
    -------
    mel_db : np.ndarray of shape (n_mels, time_frames)
    """
    audio = np.pad(audio, n_fft // 2)
    window_fn = np.hanning(n_fft)

    frames = np.array([
        audio[i:i + n_fft] * window_fn
        for i in range(0, len(audio) - n_fft, hop)
    ], dtype=np.float32)

    # Power spectrum
    power = np.abs(np.fft.rfft(frames, n=n_fft)) ** 2   # (time, freq_bins)

    # Apply mel filterbank
    mel = np.dot(power, _FILTERBANK.T)                    # (time, n_mels)
    mel_db = 10 * np.log10(mel + 1e-9)                    # (time, n_mels)

    mel_db = mel_db.T                                     # (n_mels, time)

    if normalize:
        mean = mel_db.mean()
        std  = mel_db.std()
        mel_db = (mel_db - mean) / (std + 1e-8)

    return mel_db.astype(np.float32)


def pad_or_crop(mel: np.ndarray, target_frames: int = TARGET_FRAMES) -> np.ndarray:
    """
    Ensure the time dimension is exactly target_frames.
    Crop from centre if longer, pad with zeros if shorter.
    """
    n_mels, t = mel.shape
    if t >= target_frames:
        start = (t - target_frames) // 2
        return mel[:, start:start + target_frames]
    else:
        pad = target_frames - t
        left  = pad // 2
        right = pad - left
        return np.pad(mel, ((0, 0), (left, right)))


def apply_spec_augment(mel: np.ndarray) -> np.ndarray:
    """
    SpecAugment: randomly mask time and frequency bands.
    Applied only during training (data augmentation).

    Based on: Park et al. 2019 — SpecAugment: A Simple Data Augmentation
    Method for Automatic Speech Recognition.
    """
    mel = mel.copy()
    n_mels, n_frames = mel.shape

    # Frequency masking
    f_mask = int(n_mels * FREQ_MASK_RATIO)
    if f_mask > 0:
        f0 = np.random.randint(0, n_mels - f_mask)
        mel[f0:f0 + f_mask, :] = 0.0

    # Time masking
    t_mask = int(n_frames * TIME_MASK_RATIO)
    if t_mask > 0:
        t0 = np.random.randint(0, n_frames - t_mask)
        mel[:, t0:t0 + t_mask] = 0.0

    return mel


def extract_all_features(
    audio: np.ndarray,
    sr: int,
    windows: list[np.ndarray],
    augment: bool = False,
    aug_multiplier: int = 1
) -> list[np.ndarray]:
    """
    Convert a list of audio windows to Mel spectrogram features.
    Optionally apply SpecAugment augmentation.

    Parameters
    ----------
    audio         : full audio (unused here, kept for API consistency)
    sr            : sample rate
    windows       : list of audio windows from slice_audio()
    augment       : whether to apply SpecAugment
    aug_multiplier: how many augmented copies to create per window

    Returns
    -------
    list of (n_mels, TARGET_FRAMES) float32 arrays
    """
    features = []
    for win in windows:
        mel = audio_to_melspec(win, sr)
        mel = pad_or_crop(mel, TARGET_FRAMES)
        features.append(mel)

        if augment:
            for _ in range(aug_multiplier - 1):
                aug_mel = apply_spec_augment(mel)
                # Random amplitude scaling
                scale = np.random.uniform(0.8, 1.2)
                aug_mel = aug_mel * scale
                features.append(aug_mel)

    return features
