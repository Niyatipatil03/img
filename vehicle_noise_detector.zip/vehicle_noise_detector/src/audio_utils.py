# src/audio_utils.py — Audio loading, resampling, and speech removal

import wave
import numpy as np
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import (
    SAMPLE_RATE, SPEECH_ENERGY_THRESHOLD, SILENCE_THRESHOLD,
    SPEECH_REPLACEMENT_AMP
)


def load_wav(path: str, target_sr: int = SAMPLE_RATE) -> tuple[np.ndarray, int]:
    """
    Load a .wav file, convert to mono float32, and resample to target_sr.
    Supports 8-bit and 16-bit PCM wav files.
    """
    with wave.open(path, 'rb') as wf:
        sr        = wf.getframerate()
        n_ch      = wf.getnchannels()
        sampwidth = wf.getsampwidth()
        raw       = wf.readframes(wf.getnframes())

    if sampwidth == 1:
        audio = np.frombuffer(raw, dtype=np.uint8).astype(np.float32) / 128.0 - 1.0
    elif sampwidth == 2:
        audio = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    elif sampwidth == 4:
        audio = np.frombuffer(raw, dtype=np.int32).astype(np.float32) / 2147483648.0
    else:
        raise ValueError(f"Unsupported sample width: {sampwidth}")

    # Stereo → mono
    if n_ch == 2:
        audio = audio.reshape(-1, 2).mean(axis=1)

    # Resample if needed (linear interpolation — good enough for this task)
    if sr != target_sr:
        original_len = len(audio)
        new_len = int(original_len * target_sr / sr)
        audio = np.interp(
            np.linspace(0, original_len - 1, new_len),
            np.arange(original_len),
            audio
        )

    return audio.astype(np.float32), target_sr


def rms_db(signal: np.ndarray) -> float:
    """Compute RMS energy in dBFS."""
    return float(20 * np.log10(np.sqrt(np.mean(signal ** 2)) + 1e-9))


def remove_speech_energy_vad(
    audio: np.ndarray,
    sr: int,
    frame_ms: float = 20.0,
    speech_threshold_db: float = SPEECH_ENERGY_THRESHOLD,
    replacement_amp: float = SPEECH_REPLACEMENT_AMP
) -> np.ndarray:
    """
    Simple energy-based Voice Activity Detection.
    Replaces frames above speech_threshold_db with low-amplitude noise.

    Why not silence? Complete silence creates artificial flat regions on the
    Mel spectrogram that can confuse the model. Low-amplitude noise looks
    neutral and natural.

    Parameters
    ----------
    audio              : mono float32 waveform
    sr                 : sample rate
    frame_ms           : VAD frame length in milliseconds
    speech_threshold_db: frames above this are treated as speech
    replacement_amp    : std dev of replacement Gaussian noise

    Returns
    -------
    clean audio with speech segments replaced
    """
    frame_samples = int(frame_ms * sr / 1000)
    clean = audio.copy()
    speech_frames = 0
    total_frames  = 0

    for i in range(0, len(audio) - frame_samples, frame_samples):
        frame = audio[i:i + frame_samples]
        total_frames += 1
        if rms_db(frame) > speech_threshold_db:
            speech_frames += 1
            clean[i:i + frame_samples] = np.random.normal(
                0, replacement_amp, frame_samples
            ).astype(np.float32)

    speech_pct = 100 * speech_frames / max(total_frames, 1)
    return clean, speech_pct


def is_valid_window(
    audio: np.ndarray,
    skip_threshold_db: float = -15.0,
    silence_threshold_db: float = SILENCE_THRESHOLD
) -> bool:
    """
    Returns False if the window is too loud (speech-heavy) or too quiet (silence).
    Windows that fail this check are excluded from the dataset.
    """
    energy = rms_db(audio)
    if energy > skip_threshold_db:
        return False   # likely speech-dominated
    if energy < silence_threshold_db:
        return False   # silence — no useful signal
    return True


def slice_audio(
    audio: np.ndarray,
    sr: int,
    window_sec: float,
    hop_sec: float
) -> list[np.ndarray]:
    """
    Slice a long recording into overlapping fixed-length windows.
    Returns list of audio arrays each of length window_sec * sr.
    """
    win_samples = int(window_sec * sr)
    hop_samples = int(hop_sec * sr)
    windows = []
    for start in range(0, len(audio) - win_samples, hop_samples):
        windows.append(audio[start:start + win_samples])
    return windows
