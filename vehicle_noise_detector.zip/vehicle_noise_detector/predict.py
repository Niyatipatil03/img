# predict.py — Run inference on new vehicle audio files

import os
import sys
import argparse
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import (
    MODELS_DIR, OUTPUTS_DIR, SAMPLE_RATE,
    WINDOW_SEC, HOP_SEC,
    WINDOW_SKIP_THRESHOLD, SILENCE_THRESHOLD,
    INFERENCE_THRESHOLD, VOTE_THRESHOLD,
    N_MELS, TARGET_FRAMES
)
from src.audio_utils import load_wav, remove_speech_energy_vad, slice_audio, is_valid_window
from src.features import extract_all_features
from src.model import VehicleNoiseNet

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def load_model(model_path: str = None) -> VehicleNoiseNet:
    if model_path is None:
        model_path = os.path.join(MODELS_DIR, "best_model.pt")

    if not os.path.exists(model_path):
        raise FileNotFoundError(
            f"No model found at {model_path}. Run train.py first."
        )

    model = VehicleNoiseNet().to(DEVICE)
    ckpt  = torch.load(model_path, map_location=DEVICE)
    model.load_state_dict(ckpt['model_state'])
    model.eval()
    print(f"Model loaded from {model_path}  "
          f"(trained fold {ckpt.get('fold','?')}, "
          f"val_f1={ckpt.get('val_f1',0):.4f})")
    return model


def predict_file(
    path: str,
    model: VehicleNoiseNet,
    threshold: float = INFERENCE_THRESHOLD,
    vote_threshold: float = VOTE_THRESHOLD,
    save_plot: bool = True
) -> dict:
    """
    Run full inference pipeline on a single audio file.

    Returns dict with:
        verdict      : 'OK' or 'Not-OK'
        confidence   : probability of Not-OK (0.0 – 1.0)
        not_ok_ratio : fraction of windows classified as Not-OK
        window_probs : per-window probabilities
        speech_pct   : percentage of speech detected and removed
    """
    print(f"\nAnalyzing: {os.path.basename(path)}")
    print("─" * 50)

    # Load + speech removal
    audio, sr = load_wav(path, SAMPLE_RATE)
    clean, speech_pct = remove_speech_energy_vad(audio, sr)
    print(f"  Speech detected and removed : {speech_pct:.1f}% of audio")

    # Slice
    all_windows = slice_audio(clean, sr, WINDOW_SEC, HOP_SEC)
    valid_windows = [
        w for w in all_windows
        if is_valid_window(w, WINDOW_SKIP_THRESHOLD, SILENCE_THRESHOLD)
    ]
    print(f"  Valid windows for analysis  : {len(valid_windows)} / {len(all_windows)}")

    if not valid_windows:
        return {
            'verdict': 'UNKNOWN', 'confidence': 0.5,
            'not_ok_ratio': 0.0, 'window_probs': [],
            'speech_pct': speech_pct, 'error': 'No valid windows'
        }

    # Features → predictions
    features = extract_all_features(clean, sr, valid_windows, augment=False)
    window_probs = []

    with torch.no_grad():
        for feat in features:
            tensor = torch.FloatTensor(feat).unsqueeze(0).unsqueeze(0).to(DEVICE)
            prob   = torch.sigmoid(model(tensor)).item()
            window_probs.append(prob)

    window_probs  = np.array(window_probs)
    not_ok_ratio  = float(np.mean(window_probs >= threshold))
    mean_prob     = float(np.mean(window_probs))
    max_prob      = float(np.max(window_probs))

    # Verdict: flag as Not-OK if enough windows cross the threshold
    verdict = "Not-OK" if not_ok_ratio >= vote_threshold else "OK"

    print(f"  Mean Not-OK probability     : {mean_prob:.3f}")
    print(f"  Max  Not-OK probability     : {max_prob:.3f}")
    print(f"  Not-OK windows              : {not_ok_ratio*100:.1f}%  "
          f"(threshold: {vote_threshold*100:.0f}%)")
    print(f"\n  ╔══════════════════════════╗")
    print(f"  ║  VERDICT : {verdict:<14} ║")
    print(f"  ║  Confidence : {mean_prob:.2%}       ║")
    print(f"  ╚══════════════════════════╝")

    result = {
        'file':        os.path.basename(path),
        'verdict':     verdict,
        'confidence':  mean_prob,
        'not_ok_ratio': not_ok_ratio,
        'window_probs': window_probs.tolist(),
        'speech_pct':  speech_pct,
    }

    if save_plot:
        _save_prediction_plot(path, audio, sr, window_probs, result)

    return result


def _save_prediction_plot(path, audio, sr, window_probs, result):
    """Save a visual summary of the prediction."""
    fname = os.path.splitext(os.path.basename(path))[0]
    out   = os.path.join(OUTPUTS_DIR, f"prediction_{fname}.png")
    os.makedirs(OUTPUTS_DIR, exist_ok=True)

    fig, axes = plt.subplots(2, 1, figsize=(14, 7), facecolor='#0f0f1a')
    fig.suptitle(
        f"Prediction: {result['file']}  →  {result['verdict']}  "
        f"(confidence: {result['confidence']:.2%})",
        color='white', fontsize=12, fontweight='bold'
    )
    BG = '#0d0d1a'
    color = '#ff6b6b' if result['verdict'] == 'Not-OK' else '#00c896'

    # Waveform
    ax1 = axes[0]
    t = np.linspace(0, len(audio)/sr, len(audio))
    ax1.plot(t[::100], audio[::100], color='#00a8ff', linewidth=0.4, alpha=0.7)
    ax1.set_facecolor(BG)
    ax1.set_title('Waveform', color='#aaa', fontsize=9)
    ax1.set_xlabel('Time (s)', color='#888', fontsize=8)
    ax1.tick_params(colors='#666', labelsize=7)
    for sp in ax1.spines.values(): sp.set_color('#333')

    # Per-window probability
    ax2 = axes[1]
    x = np.arange(len(window_probs))
    bar_colors = ['#ff6b6b' if p >= INFERENCE_THRESHOLD else '#00c896'
                  for p in window_probs]
    ax2.bar(x, window_probs, color=bar_colors, alpha=0.85, width=0.8)
    ax2.axhline(INFERENCE_THRESHOLD, color='orange', linewidth=1.5,
                linestyle='--', label=f'Window threshold ({INFERENCE_THRESHOLD})')
    ax2.axhline(result['confidence'], color=color, linewidth=1,
                linestyle=':', label=f'Mean prob ({result["confidence"]:.3f})')
    ax2.set_facecolor(BG)
    ax2.set_title('Per-window Not-OK probability', color='#aaa', fontsize=9)
    ax2.set_xlabel('Window index', color='#888', fontsize=8)
    ax2.set_ylabel('P(Not-OK)', color='#888', fontsize=8)
    ax2.set_ylim(0, 1)
    ax2.legend(fontsize=8, facecolor='#1a1a2e', labelcolor='white')
    ax2.tick_params(colors='#666', labelsize=7)
    for sp in ax2.spines.values(): sp.set_color('#333')

    plt.tight_layout()
    plt.savefig(out, dpi=130, bbox_inches='tight', facecolor='#0f0f1a')
    plt.close()
    print(f"  Plot saved → {out}")


def predict_batch(file_list: list, model: VehicleNoiseNet) -> list:
    """Run prediction on multiple files and print a summary table."""
    results = []
    for path in file_list:
        if os.path.exists(path):
            r = predict_file(path, model, save_plot=True)
            results.append(r)
        else:
            print(f"[WARN] File not found: {path}")

    print(f"\n{'='*60}")
    print(f" BATCH SUMMARY")
    print(f"{'='*60}")
    print(f"  {'File':<40} {'Verdict':<10} {'Confidence'}")
    print(f"  {'─'*38} {'─'*9} {'─'*10}")
    for r in results:
        icon = '✗' if r['verdict'] == 'Not-OK' else '✓'
        print(f"  {icon} {r['file']:<38} {r['verdict']:<10} {r['confidence']:.2%}")

    ok_count    = sum(1 for r in results if r['verdict'] == 'OK')
    notok_count = sum(1 for r in results if r['verdict'] == 'Not-OK')
    print(f"\n  Total: {len(results)}  |  OK: {ok_count}  |  Not-OK: {notok_count}")
    return results


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Predict vehicle noise quality from audio files"
    )
    parser.add_argument(
        "files", nargs="+",
        help="Path(s) to .wav audio file(s) to analyze"
    )
    parser.add_argument(
        "--model", default=None,
        help="Path to model checkpoint (default: models/best_model.pt)"
    )
    parser.add_argument(
        "--threshold", type=float, default=INFERENCE_THRESHOLD,
        help=f"Window classification threshold (default: {INFERENCE_THRESHOLD})"
    )
    parser.add_argument(
        "--vote", type=float, default=VOTE_THRESHOLD,
        help=f"Vote threshold for final verdict (default: {VOTE_THRESHOLD})"
    )
    args = parser.parse_args()

    model = load_model(args.model)

    if len(args.files) == 1:
        predict_file(args.files[0], model, args.threshold, args.vote)
    else:
        predict_batch(args.files, model)
