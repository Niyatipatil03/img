# train.py — K-Fold cross-validated training with full logging

import os
import sys
import json
import time
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    classification_report, confusion_matrix,
    roc_auc_score, f1_score
)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import (
    MODELS_DIR, OUTPUTS_DIR,
    K_FOLDS, EPOCHS, BATCH_SIZE,
    LEARNING_RATE, WEIGHT_DECAY,
    PATIENCE, POS_WEIGHT, RANDOM_SEED,
    INFERENCE_THRESHOLD, AUGMENT, AUG_MULTIPLIER
)
from src.dataset import build_full_dataset, VehicleNoiseDataset
from src.model import VehicleNoiseNet

os.makedirs(MODELS_DIR,  exist_ok=True)
os.makedirs(OUTPUTS_DIR, exist_ok=True)
torch.manual_seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


# ── Helpers ──────────────────────────────────────────────────────────────────

def get_metrics(model, loader, threshold=INFERENCE_THRESHOLD):
    model.eval()
    all_probs, all_preds, all_labels = [], [], []
    total_loss = 0.0
    criterion  = nn.BCEWithLogitsLoss()

    with torch.no_grad():
        for xb, yb in loader:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            logits = model(xb)
            loss   = criterion(logits, yb)
            total_loss += loss.item() * len(yb)
            probs  = torch.sigmoid(logits).cpu().numpy()
            preds  = (probs >= threshold).astype(int)
            all_probs.extend(probs.tolist())
            all_preds.extend(preds.tolist())
            all_labels.extend(yb.cpu().numpy().astype(int).tolist())

    avg_loss = total_loss / len(loader.dataset)
    acc  = sum(p == l for p, l in zip(all_preds, all_labels)) / len(all_labels)
    f1   = f1_score(all_labels, all_preds, zero_division=0)
    try:
        auc = roc_auc_score(all_labels, all_probs)
    except Exception:
        auc = 0.5

    return avg_loss, acc, f1, auc, all_preds, all_labels, all_probs


def plot_training_curves(histories: list, save_path: str):
    """Plot training and validation curves across all folds."""
    fig, axes = plt.subplots(1, 3, figsize=(16, 5), facecolor='#0f0f1a')
    fig.suptitle('Training curves — all folds', color='white', fontsize=13)

    colors = ['#00c896', '#00a8ff', '#ff6b6b', '#ffaa00', '#cc88ff']
    metrics = ['loss', 'acc', 'f1']
    titles  = ['Loss', 'Accuracy', 'F1 Score']

    for ax, metric, title in zip(axes, metrics, titles):
        for fold_idx, hist in enumerate(histories):
            c = colors[fold_idx % len(colors)]
            epochs_range = range(1, len(hist[f'train_{metric}']) + 1)
            ax.plot(epochs_range, hist[f'train_{metric}'],
                    color=c, linewidth=1, alpha=0.5, linestyle='--')
            ax.plot(epochs_range, hist[f'val_{metric}'],
                    color=c, linewidth=1.5, label=f'Fold {fold_idx+1}')
        ax.set_title(title, color='white', fontsize=10)
        ax.set_facecolor('#0d0d1a')
        ax.tick_params(colors='#888', labelsize=8)
        ax.set_xlabel('Epoch', color='#888', fontsize=8)
        for sp in ax.spines.values(): sp.set_color('#333')
        if metric == 'loss':
            ax.legend(fontsize=7, facecolor='#1a1a2e', labelcolor='white')

    plt.tight_layout()
    plt.savefig(save_path, dpi=130, bbox_inches='tight', facecolor='#0f0f1a')
    plt.close()
    print(f"Training curves saved → {save_path}")


def plot_confusion_matrix(cm: np.ndarray, fold: int, save_path: str):
    fig, ax = plt.subplots(figsize=(5, 4), facecolor='#0f0f1a')
    im = ax.imshow(cm, cmap='Blues')
    ax.set_xticks([0, 1]); ax.set_yticks([0, 1])
    ax.set_xticklabels(['OK', 'Not-OK'], color='white')
    ax.set_yticklabels(['OK', 'Not-OK'], color='white')
    ax.set_xlabel('Predicted', color='#aaa')
    ax.set_ylabel('Actual', color='#aaa')
    ax.set_title(f'Confusion matrix — Fold {fold}', color='white', fontsize=10)
    for i in range(2):
        for j in range(2):
            ax.text(j, i, str(cm[i, j]), ha='center', va='center',
                    color='white', fontsize=14, fontweight='bold')
    ax.set_facecolor('#0d0d1a')
    fig.colorbar(im, ax=ax)
    plt.tight_layout()
    plt.savefig(save_path, dpi=120, bbox_inches='tight', facecolor='#0f0f1a')
    plt.close()


# ── Main training loop ───────────────────────────────────────────────────────

def train():
    print(f"\n{'='*70}")
    print(" VEHICLE NOISE DETECTOR — TRAINING")
    print(f"{'='*70}")
    print(f"Device : {DEVICE}")
    print(f"Folds  : {K_FOLDS}  |  Epochs: {EPOCHS}  |  Batch: {BATCH_SIZE}")
    print(f"LR     : {LEARNING_RATE}  |  Augment: {AUGMENT} (x{AUG_MULTIPLIER})")

    # ── Build dataset ────────────────────────────────────────────────────────
    cache = os.path.join(OUTPUTS_DIR, "dataset_cache.pkl")
    features, labels = build_full_dataset(cache_path=cache)

    if len(features) == 0:
        print("\n[ERROR] No data found. Add .wav files to data/ok/ and data/notok/")
        return

    X = np.array(labels)   # used only for stratified splitting

    # ── K-Fold cross validation ───────────────────────────────────────────────
    skf = StratifiedKFold(n_splits=K_FOLDS, shuffle=True, random_state=RANDOM_SEED)
    fold_results = []
    all_histories = []

    for fold, (train_idx, val_idx) in enumerate(skf.split(X, X)):
        fold_num = fold + 1
        print(f"\n{'─'*70}")
        print(f" FOLD {fold_num} / {K_FOLDS}  —  "
              f"train: {len(train_idx)} | val: {len(val_idx)}")
        print(f"{'─'*70}")

        tr_feats = [features[i] for i in train_idx]
        tr_labs  = [labels[i]   for i in train_idx]
        vl_feats = [features[i] for i in val_idx]
        vl_labs  = [labels[i]   for i in val_idx]

        tr_ds = VehicleNoiseDataset(tr_feats, tr_labs, augment=True)
        vl_ds = VehicleNoiseDataset(vl_feats, vl_labs, augment=False)
        tr_dl = DataLoader(tr_ds, batch_size=BATCH_SIZE, shuffle=True,  num_workers=0)
        vl_dl = DataLoader(vl_ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)

        model     = VehicleNoiseNet().to(DEVICE)
        criterion = nn.BCEWithLogitsLoss(
            pos_weight=torch.tensor([POS_WEIGHT]).to(DEVICE)
        )
        optimizer = optim.AdamW(
            model.parameters(), lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY
        )
        scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS)

        best_val_f1   = 0.0
        best_val_acc  = 0.0
        patience_wait = 0
        best_model_path = os.path.join(MODELS_DIR, f"best_fold{fold_num}.pt")

        history = {
            'train_loss': [], 'val_loss': [],
            'train_acc':  [], 'val_acc':  [],
            'train_f1':   [], 'val_f1':   [],
        }

        for epoch in range(1, EPOCHS + 1):
            # ── Train ────────────────────────────────────────────────────────
            model.train()
            tr_loss = 0.0
            tr_correct, tr_total = 0, 0

            for xb, yb in tr_dl:
                xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                optimizer.zero_grad()
                logits = model(xb)
                loss   = criterion(logits, yb)
                loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()
                tr_loss += loss.item() * len(yb)
                preds    = (torch.sigmoid(logits) >= INFERENCE_THRESHOLD).float()
                tr_correct += (preds == yb).sum().item()
                tr_total   += len(yb)

            scheduler.step()
            tr_loss /= len(tr_ds)
            tr_acc   = tr_correct / tr_total
            _, _, tr_f1, _, _, _, _ = get_metrics(model, tr_dl)

            # ── Validate ─────────────────────────────────────────────────────
            vl_loss, vl_acc, vl_f1, vl_auc, vl_preds, vl_true, _ = \
                get_metrics(model, vl_dl)

            history['train_loss'].append(tr_loss)
            history['val_loss'].append(vl_loss)
            history['train_acc'].append(tr_acc)
            history['val_acc'].append(vl_acc)
            history['train_f1'].append(tr_f1)
            history['val_f1'].append(vl_f1)

            if epoch % 5 == 0 or epoch == 1:
                print(f"  Epoch {epoch:3d}/{EPOCHS} | "
                      f"tr_loss: {tr_loss:.4f}  tr_acc: {tr_acc:.3f} | "
                      f"val_loss: {vl_loss:.4f}  val_acc: {vl_acc:.3f}  "
                      f"val_f1: {vl_f1:.3f}  AUC: {vl_auc:.3f}")

            # ── Early stopping on F1 ──────────────────────────────────────
            if vl_f1 > best_val_f1:
                best_val_f1  = vl_f1
                best_val_acc = vl_acc
                patience_wait = 0
                torch.save({
                    'fold':        fold_num,
                    'epoch':       epoch,
                    'model_state': model.state_dict(),
                    'val_f1':      vl_f1,
                    'val_acc':     vl_acc,
                    'val_auc':     vl_auc,
                }, best_model_path)
            else:
                patience_wait += 1
                if patience_wait >= PATIENCE:
                    print(f"  Early stopping at epoch {epoch} "
                          f"(best val F1: {best_val_f1:.4f})")
                    break

        # ── Load best checkpoint for this fold and evaluate ──────────────────
        ckpt = torch.load(best_model_path, map_location=DEVICE)
        model.load_state_dict(ckpt['model_state'])
        _, _, _, _, final_preds, final_true, _ = get_metrics(model, vl_dl)

        cm = confusion_matrix(final_true, final_preds)
        report = classification_report(
            final_true, final_preds,
            target_names=['OK', 'Not-OK'], zero_division=0
        )

        print(f"\n  Best val F1 : {best_val_f1:.4f}")
        print(f"  Best val Acc: {best_val_acc:.4f}")
        print(f"\n{report}")

        plot_confusion_matrix(
            cm, fold_num,
            os.path.join(OUTPUTS_DIR, f"confusion_fold{fold_num}.png")
        )

        fold_results.append({
            'fold': fold_num, 'val_f1': best_val_f1,
            'val_acc': best_val_acc, 'confusion_matrix': cm.tolist()
        })
        all_histories.append(history)

    # ── Summary ───────────────────────────────────────────────────────────────
    print(f"\n{'='*70}")
    print(" K-FOLD SUMMARY")
    print(f"{'='*70}")
    f1s   = [r['val_f1']  for r in fold_results]
    accs  = [r['val_acc'] for r in fold_results]

    for r in fold_results:
        print(f"  Fold {r['fold']} — Acc: {r['val_acc']:.4f}  F1: {r['val_f1']:.4f}")

    print(f"\n  Mean Acc : {np.mean(accs):.4f} ± {np.std(accs):.4f}")
    print(f"  Mean F1  : {np.mean(f1s):.4f} ± {np.std(f1s):.4f}")

    # Save best overall model (highest F1)
    best_fold = fold_results[np.argmax(f1s)]['fold']
    best_src  = os.path.join(MODELS_DIR, f"best_fold{best_fold}.pt")
    best_dst  = os.path.join(MODELS_DIR, "best_model.pt")
    import shutil
    shutil.copy(best_src, best_dst)
    print(f"\n  Best model (Fold {best_fold}) saved → {best_dst}")

    # Save training summary
    summary = {
        'folds': fold_results,
        'mean_acc': float(np.mean(accs)),
        'std_acc':  float(np.std(accs)),
        'mean_f1':  float(np.mean(f1s)),
        'std_f1':   float(np.std(f1s)),
        'best_fold': best_fold,
    }
    with open(os.path.join(OUTPUTS_DIR, 'training_summary.json'), 'w') as f:
        json.dump(summary, f, indent=2)

    plot_training_curves(
        all_histories,
        os.path.join(OUTPUTS_DIR, 'training_curves.png')
    )
    print(f"\nAll outputs saved to {OUTPUTS_DIR}/")
    print("Training complete.")


if __name__ == "__main__":
    train()
