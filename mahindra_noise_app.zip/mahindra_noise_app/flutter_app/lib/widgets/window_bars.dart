// lib/widgets/window_bars.dart
import 'package:flutter/material.dart';
import '../theme.dart';

class WindowBarsView extends StatelessWidget {
  final List<double> probs;
  const WindowBarsView({super.key, required this.probs});

  @override
  Widget build(BuildContext context) {
    if (probs.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          const Text('WINDOW SCORES',
              style: TextStyle(color: MahindraTheme.greyLight,
                  fontSize: 11, fontWeight: FontWeight.w700,
                  letterSpacing: 1.2)),
          const Spacer(),
          _legend(MahindraTheme.green, 'OK'),
          const SizedBox(width: 12),
          _legend(MahindraTheme.red, 'Noise'),
        ]),
        const SizedBox(height: 10),
        SizedBox(
          height: 56,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: probs.map((p) {
              final isNoise = p >= 0.5;
              final color   = isNoise ? MahindraTheme.red : MahindraTheme.green;
              final barW    = probs.length > 50 ? 4.0 : probs.length > 30 ? 6.0 : 9.0;
              return Padding(
                padding: const EdgeInsets.only(right: 2),
                child: Tooltip(
                  message: '${(p * 100).toStringAsFixed(0)}%',
                  child: Container(
                    width: barW,
                    height: (p * 50).clamp(2.0, 50.0),
                    decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 4),
        // Threshold line label
        Row(children: [
          Container(width: 20, height: 1,
              color: MahindraTheme.amber.withOpacity(0.7)),
          const SizedBox(width: 6),
          const Text('50% threshold',
              style: TextStyle(color: MahindraTheme.amber, fontSize: 9)),
        ]),
      ],
    );
  }

  Widget _legend(Color c, String label) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Container(width: 10, height: 10,
          decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(2))),
      const SizedBox(width: 4),
      Text(label, style: const TextStyle(color: MahindraTheme.greyLight, fontSize: 10)),
    ],
  );
}
