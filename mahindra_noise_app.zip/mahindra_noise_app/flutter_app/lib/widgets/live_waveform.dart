// lib/widgets/live_waveform.dart
import 'dart:math';
import 'package:flutter/material.dart';
import '../theme.dart';

class LiveWaveform extends StatefulWidget {
  final bool isRecording;
  const LiveWaveform({super.key, required this.isRecording});
  @override
  State<LiveWaveform> createState() => _LiveWaveformState();
}

class _LiveWaveformState extends State<LiveWaveform>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  final _rng  = Random();
  final _bars = List.generate(40, (_) => 0.05);

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 80),
    )..addListener(_update)..repeat();
  }

  void _update() {
    if (!mounted) return;
    setState(() {
      if (widget.isRecording) {
        for (int i = 0; i < _bars.length; i++)
          _bars[i] = 0.05 + _rng.nextDouble() * 0.95;
      } else {
        for (int i = 0; i < _bars.length; i++)
          _bars[i] = (_bars[i] * 0.85).clamp(0.05, 1.0);
      }
    });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 90,
      child: CustomPaint(painter: _WavePainter(_bars, widget.isRecording)),
    );
  }
}

class _WavePainter extends CustomPainter {
  final List<double> bars;
  final bool active;
  _WavePainter(this.bars, this.active);

  @override
  void paint(Canvas canvas, Size size) {
    final w     = size.width / bars.length;
    final midY  = size.height / 2;
    for (int i = 0; i < bars.length; i++) {
      final h     = bars[i] * midY * 0.92;
      final x     = i * w + w / 2;
      final alpha = active ? (0.5 + bars[i] * 0.5) : 0.2;
      final paint = Paint()
        ..color = (active ? MahindraTheme.red : MahindraTheme.greyLight)
            .withOpacity(alpha)
        ..strokeCap = StrokeCap.round
        ..strokeWidth = (w * 0.55).clamp(2.0, 8.0);
      canvas.drawLine(Offset(x, midY - h), Offset(x, midY + h), paint);
    }
  }

  @override
  bool shouldRepaint(_WavePainter old) => true;
}
