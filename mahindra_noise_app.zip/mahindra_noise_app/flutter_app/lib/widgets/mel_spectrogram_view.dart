// lib/widgets/mel_spectrogram_view.dart
import 'package:flutter/material.dart';
import '../services/inference_service.dart';
import '../theme.dart';

class MelSpectrogramView extends StatelessWidget {
  final MelSpectrogramData data;
  final bool isNotOk;

  const MelSpectrogramView({
    super.key,
    required this.data,
    required this.isNotOk,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          const Text('MEL SPECTROGRAM',
              style: TextStyle(color: MahindraTheme.greyLight,
                  fontSize: 11, fontWeight: FontWeight.w700,
                  letterSpacing: 1.2)),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: MahindraTheme.grey,
              borderRadius: BorderRadius.circular(4),
            ),
            child: const Text('300Hz – 10kHz',
                style: TextStyle(color: MahindraTheme.greyLight, fontSize: 10)),
          ),
        ]),
        const SizedBox(height: 10),
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: SizedBox(
            height: 130,
            child: CustomPaint(
              painter: _MelPainter(data: data, isNotOk: isNotOk),
              size: const Size(double.infinity, 130),
            ),
          ),
        ),
        const SizedBox(height: 6),
        // Frequency axis labels
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('300 Hz', style: TextStyle(color: MahindraTheme.greyLight, fontSize: 9)),
          const Text('2 kHz',  style: TextStyle(color: MahindraTheme.greyLight, fontSize: 9)),
          const Text('5 kHz',  style: TextStyle(color: MahindraTheme.greyLight, fontSize: 9)),
          const Text('10 kHz', style: TextStyle(color: MahindraTheme.greyLight, fontSize: 9)),
        ]),
        const SizedBox(height: 8),
        // Colorbar legend
        Row(children: [
          const Text('Low energy', style: TextStyle(color: MahindraTheme.greyLight, fontSize: 9)),
          const SizedBox(width: 8),
          Expanded(
            child: Container(
              height: 8,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                gradient: LinearGradient(
                  colors: isNotOk
                      ? [Colors.black, Colors.blue.shade900,
                          Colors.purple.shade700, MahindraTheme.red]
                      : [Colors.black, Colors.blue.shade900,
                          Colors.teal, Colors.green.shade400],
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          const Text('High energy', style: TextStyle(color: MahindraTheme.greyLight, fontSize: 9)),
        ]),
      ],
    );
  }
}

class _MelPainter extends CustomPainter {
  final MelSpectrogramData data;
  final bool isNotOk;

  _MelPainter({required this.data, required this.isNotOk});

  @override
  void paint(Canvas canvas, Size size) {
    final nM = data.nMels;
    final nF = data.nFrames;
    final cW = size.width  / nF;
    final cH = size.height / nM;

    for (int m = 0; m < nM; m++) {
      for (int f = 0; f < nF; f++) {
        final v = data.data[nM - 1 - m][f]; // flip vertically (low freq at bottom)
        canvas.drawRect(
          Rect.fromLTWH(f * cW, m * cH, cW + 0.5, cH + 0.5),
          Paint()..color = _getColor(v, isNotOk),
        );
      }
    }
  }

  Color _getColor(double v, bool red) {
    // Multi-stop heatmap: black → blue → purple/teal → red/green
    if (v < 0.25) {
      final t = v / 0.25;
      return Color.lerp(Colors.black, Colors.blue.shade900, t)!;
    } else if (v < 0.5) {
      final t = (v - 0.25) / 0.25;
      return Color.lerp(Colors.blue.shade900,
          red ? Colors.purple.shade700 : Colors.teal.shade600, t)!;
    } else if (v < 0.75) {
      final t = (v - 0.5) / 0.25;
      return Color.lerp(
          red ? Colors.purple.shade700 : Colors.teal.shade600,
          red ? Colors.orange        : Colors.green.shade400, t)!;
    } else {
      final t = (v - 0.75) / 0.25;
      return Color.lerp(
          red ? Colors.orange : Colors.green.shade400,
          red ? MahindraTheme.red : const Color(0xFF00FF88), t)!;
    }
  }

  @override
  bool shouldRepaint(_) => false;
}
