// lib/widgets/waveform_snapshot.dart
import 'package:flutter/material.dart';
import '../theme.dart';

class WaveformSnapshot extends StatelessWidget {
  final List<double> samples;
  final bool isNotOk;

  const WaveformSnapshot({
    super.key,
    required this.samples,
    required this.isNotOk,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('WAVEFORM',
            style: TextStyle(color: MahindraTheme.greyLight,
                fontSize: 11, fontWeight: FontWeight.w700,
                letterSpacing: 1.2)),
        const SizedBox(height: 10),
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Container(
            height: 80,
            color: MahindraTheme.bgCardAlt,
            child: CustomPaint(
              painter: _WaveSnapshotPainter(
                  samples: samples, isNotOk: isNotOk),
              size: const Size(double.infinity, 80),
            ),
          ),
        ),
      ],
    );
  }
}

class _WaveSnapshotPainter extends CustomPainter {
  final List<double> samples;
  final bool isNotOk;
  _WaveSnapshotPainter({required this.samples, required this.isNotOk});

  @override
  void paint(Canvas canvas, Size size) {
    if (samples.isEmpty) return;
    final color  = isNotOk ? MahindraTheme.red : MahindraTheme.green;
    final midY   = size.height / 2;
    final stepX  = size.width / samples.length;

    // Fill area
    final fillPath = Path()..moveTo(0, midY);
    for (int i = 0; i < samples.length; i++) {
      fillPath.lineTo(i * stepX, midY - samples[i] * midY * 0.9);
    }
    fillPath.lineTo(size.width, midY);
    fillPath.close();
    canvas.drawPath(fillPath, Paint()
      ..color = color.withOpacity(0.12)
      ..style = PaintingStyle.fill);

    // Line
    final linePath = Path()..moveTo(0, midY);
    for (int i = 0; i < samples.length; i++) {
      linePath.lineTo(i * stepX, midY - samples[i] * midY * 0.9);
    }
    canvas.drawPath(linePath, Paint()
      ..color = color.withOpacity(0.85)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round);

    // Centre line
    canvas.drawLine(Offset(0, midY), Offset(size.width, midY),
        Paint()..color = MahindraTheme.grey.withOpacity(0.4)..strokeWidth = 0.5);
  }

  @override
  bool shouldRepaint(_) => false;
}
