// lib/theme.dart — Mahindra brand theme
import 'package:flutter/material.dart';

class MahindraTheme {
  // Brand colors
  static const Color red       = Color(0xFFD0021B);   // Mahindra Red
  static const Color redDark   = Color(0xFF9B0015);
  static const Color redLight  = Color(0xFFFF3347);
  static const Color white     = Color(0xFFFFFFFF);
  static const Color offWhite  = Color(0xFFF5F5F5);
  static const Color bgDark    = Color(0xFF0A0A0A);
  static const Color bgCard    = Color(0xFF161616);
  static const Color bgCardAlt = Color(0xFF1E1E1E);
  static const Color grey      = Color(0xFF3A3A3A);
  static const Color greyLight = Color(0xFF888888);
  static const Color green     = Color(0xFF00C853);
  static const Color greenDark = Color(0xFF007A33);
  static const Color amber     = Color(0xFFFFAB00);

  static ThemeData get theme => ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: bgDark,
    colorScheme: const ColorScheme.dark(
      primary:   red,
      secondary: white,
      surface:   bgCard,
      error:     redLight,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: bgDark,
      foregroundColor: white,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        color: white, fontSize: 18,
        fontWeight: FontWeight.w700, letterSpacing: 0.5,
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: red,
        foregroundColor: white,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700,
            letterSpacing: 0.5),
      ),
    ),
    cardTheme: CardTheme(
      color: bgCard,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),
  );
}
