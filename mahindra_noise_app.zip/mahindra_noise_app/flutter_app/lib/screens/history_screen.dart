// lib/screens/history_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/inference_service.dart';
import '../services/history_service.dart';
import '../widgets/mel_spectrogram_view.dart';
import '../widgets/waveform_snapshot.dart';
import '../widgets/window_bars.dart';
import '../theme.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final _svc  = HistoryService();
  List<PredictionResult> _items = [];
  bool _loading = true;
  String _filter = 'All'; // All / OK / Not-OK

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final items = await _svc.load();
    setState(() { _items = items; _loading = false; });
  }

  List<PredictionResult> get _filtered => _filter == 'All'
      ? _items
      : _items.where((r) => r.verdict == _filter).toList();

  Future<void> _clear() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: MahindraTheme.bgCard,
        title: const Text('Clear history?',
            style: TextStyle(color: Colors.white)),
        content: const Text('All saved scans will be permanently deleted.',
            style: TextStyle(color: MahindraTheme.greyLight)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel',
                  style: TextStyle(color: MahindraTheme.greyLight))),
          TextButton(onPressed: () => Navigator.pop(context, true),
              child: const Text('Delete all',
                  style: TextStyle(color: MahindraTheme.red))),
        ],
      ),
    );
    if (ok == true) { await _svc.clear(); _load(); }
  }

  @override
  Widget build(BuildContext context) {
    final okCount    = _items.where((r) => r.isOk).length;
    final notOkCount = _items.where((r) => !r.isOk).length;

    return Scaffold(
      backgroundColor: MahindraTheme.bgDark,
      appBar: AppBar(
        backgroundColor: MahindraTheme.bgDark,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Row(children: [
          Text('M', style: TextStyle(color: MahindraTheme.red,
              fontSize: 18, fontWeight: FontWeight.w900)),
          SizedBox(width: 8),
          Text('SCAN HISTORY', style: TextStyle(color: Colors.white,
              fontSize: 15, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
        ]),
        actions: [
          if (_items.isNotEmpty)
            TextButton(
              onPressed: _clear,
              child: const Text('CLEAR ALL',
                  style: TextStyle(color: MahindraTheme.red, fontSize: 12,
                      fontWeight: FontWeight.w700, letterSpacing: 0.5)),
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: MahindraTheme.red))
          : _items.isEmpty
          ? _emptyState()
          : Column(children: [
              // Summary bar
              Container(
                margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: MahindraTheme.bgCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: MahindraTheme.grey.withOpacity(0.4)),
                ),
                child: Row(children: [
                  _summaryBadge('Total', '${_items.length}', MahindraTheme.white),
                  _vDivider(),
                  _summaryBadge('OK', '$okCount', MahindraTheme.green),
                  _vDivider(),
                  _summaryBadge('Not-OK', '$notOkCount', MahindraTheme.red),
                  _vDivider(),
                  _summaryBadge('Pass rate',
                      _items.isEmpty ? '-'
                          : '${(okCount / _items.length * 100).toStringAsFixed(0)}%',
                      MahindraTheme.amber),
                ]),
              ),

              // Filter chips
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                child: Row(children: [
                  for (final f in ['All', 'OK', 'Not-OK'])
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: _filterChip(f),
                    ),
                ]),
              ),

              // List
              Expanded(
                child: _filtered.isEmpty
                    ? Center(child: Text('No "$_filter" scans yet',
                        style: const TextStyle(color: MahindraTheme.greyLight)))
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                        itemCount: _filtered.length,
                        itemBuilder: (_, i) => _HistoryTile(
                          result: _filtered[i],
                          onTap: () => Navigator.push(context,
                              MaterialPageRoute(builder: (_) =>
                                  _DetailScreen(result: _filtered[i]))),
                        ),
                      ),
              ),
            ]),
    );
  }

  Widget _filterChip(String label) {
    final active = _filter == label;
    return GestureDetector(
      onTap: () => setState(() => _filter = label),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: active ? MahindraTheme.red : MahindraTheme.bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: active ? MahindraTheme.red : MahindraTheme.grey,
          ),
        ),
        child: Text(label, style: TextStyle(
            color: active ? Colors.white : MahindraTheme.greyLight,
            fontSize: 12, fontWeight: FontWeight.w700)),
      ),
    );
  }

  Widget _summaryBadge(String label, String value, Color color) =>
      Expanded(child: Column(children: [
        Text(value, style: TextStyle(color: color, fontSize: 18,
            fontWeight: FontWeight.w800)),
        Text(label, style: const TextStyle(
            color: MahindraTheme.greyLight, fontSize: 10)),
      ]));

  Widget _vDivider() => Container(
      width: 1, height: 32, color: MahindraTheme.grey.withOpacity(0.5),
      margin: const EdgeInsets.symmetric(horizontal: 4));

  Widget _emptyState() => Center(child: Column(
    mainAxisAlignment: MainAxisAlignment.center, children: [
    const Icon(Icons.history_toggle_off, color: MahindraTheme.grey, size: 64),
    const SizedBox(height: 16),
    const Text('No scans yet', style: TextStyle(
        color: MahindraTheme.greyLight, fontSize: 16)),
    const SizedBox(height: 8),
    Text('Run your first scan from the home screen',
        style: TextStyle(color: MahindraTheme.grey, fontSize: 13)),
  ]));
}

class _HistoryTile extends StatelessWidget {
  final PredictionResult result;
  final VoidCallback onTap;
  const _HistoryTile({required this.result, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isOk  = result.isOk;
    final color = isOk ? MahindraTheme.green : MahindraTheme.red;
    final fmt   = DateFormat('dd MMM yyyy  HH:mm');

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: MahindraTheme.bgCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              isOk ? Icons.check_circle : Icons.warning_amber_rounded,
              color: color, size: 24,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(result.verdict, style: TextStyle(
                color: color, fontWeight: FontWeight.w800, fontSize: 15)),
            const SizedBox(height: 2),
            Text(fmt.format(result.timestamp),
                style: const TextStyle(
                    color: MahindraTheme.greyLight, fontSize: 11)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text('${(result.confidence * 100).toStringAsFixed(1)}%',
                style: TextStyle(color: color, fontWeight: FontWeight.w900,
                    fontSize: 16)),
            const Text('confidence', style: TextStyle(
                color: MahindraTheme.greyLight, fontSize: 9)),
          ]),
          const SizedBox(width: 8),
          const Icon(Icons.chevron_right, color: MahindraTheme.grey, size: 18),
        ]),
      ),
    );
  }
}

// ── Full detail screen for a past scan ────────────────────────────────────────
class _DetailScreen extends StatelessWidget {
  final PredictionResult result;
  const _DetailScreen({required this.result});

  @override
  Widget build(BuildContext context) {
    final isOk  = result.isOk;
    final color = isOk ? MahindraTheme.green : MahindraTheme.red;
    final fmt   = DateFormat('dd MMM yyyy  HH:mm:ss');

    return Scaffold(
      backgroundColor: MahindraTheme.bgDark,
      appBar: AppBar(
        backgroundColor: MahindraTheme.bgDark,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(fmt.format(result.timestamp),
            style: const TextStyle(color: MahindraTheme.greyLight,
                fontSize: 13, fontWeight: FontWeight.w500)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          // Verdict
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: color.withOpacity(0.5), width: 1.5),
            ),
            child: Row(children: [
              Icon(isOk ? Icons.check_circle : Icons.warning_amber_rounded,
                  color: color, size: 44),
              const SizedBox(width: 16),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(result.verdict, style: TextStyle(color: color,
                    fontSize: 26, fontWeight: FontWeight.w900)),
                Text('${(result.confidence * 100).toStringAsFixed(2)}% confidence',
                    style: const TextStyle(
                        color: MahindraTheme.greyLight, fontSize: 14)),
              ]),
            ]),
          ),

          const SizedBox(height: 16),

          // Stats
          Row(children: [
            _stat('Duration',
                '${result.audioDuration.inSeconds}s', MahindraTheme.white),
            const SizedBox(width: 12),
            _stat('Noise windows',
                '${(result.notOkRatio * 100).toStringAsFixed(0)}%',
                MahindraTheme.amber),
            const SizedBox(width: 12),
            _stat('Speech removed',
                '${result.speechPct.toStringAsFixed(1)}%',
                MahindraTheme.greyLight),
          ]),

          const SizedBox(height: 16),

          // Waveform
          _card(WaveformSnapshot(
              samples: result.waveformSnapshot, isNotOk: !isOk)),
          const SizedBox(height: 16),

          // Window bars
          _card(WindowBarsView(probs: result.windowProbs)),
          const SizedBox(height: 16),

          // Note: mel data not saved to disk (too large) — show info
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: MahindraTheme.bgCard,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: MahindraTheme.grey.withOpacity(0.4)),
            ),
            child: const Row(children: [
              Icon(Icons.info_outline, color: MahindraTheme.greyLight, size: 16),
              SizedBox(width: 10),
              Expanded(child: Text(
                'Live mel spectrogram is available during active scans only. '
                    'Waveform and window scores are saved for each scan.',
                style: TextStyle(color: MahindraTheme.greyLight, fontSize: 12),
              )),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _stat(String label, String value, Color color) => Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
      decoration: BoxDecoration(
        color: MahindraTheme.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: MahindraTheme.grey.withOpacity(0.4)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value, style: TextStyle(color: color,
            fontWeight: FontWeight.w800, fontSize: 17)),
        Text(label, style: const TextStyle(
            color: MahindraTheme.greyLight, fontSize: 10)),
      ]),
    ),
  );

  Widget _card(Widget child) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: MahindraTheme.bgCard,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: MahindraTheme.grey.withOpacity(0.4)),
    ),
    child: child,
  );
}
