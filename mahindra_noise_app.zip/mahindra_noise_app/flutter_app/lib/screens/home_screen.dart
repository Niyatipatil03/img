// lib/screens/home_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import '../services/recorder_service.dart';
import '../services/inference_service.dart';
import '../services/history_service.dart';
import '../widgets/live_waveform.dart';
import '../widgets/mel_spectrogram_view.dart';
import '../widgets/waveform_snapshot.dart';
import '../widgets/window_bars.dart';
import '../theme.dart';
import 'history_screen.dart';

enum AppState { loading, ready, recording, analyzing, result, error }

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final _recorder  = RecorderService();
  final _inference = InferenceService();
  final _history   = HistoryService();

  AppState         _state  = AppState.loading;
  PredictionResult? _result;
  String           _error  = '';
  int              _secs   = 0;
  Timer?           _timer;

  late AnimationController _pulseCtrl;
  late AnimationController _resultCtrl;
  late Animation<double>   _pulseScale;
  late Animation<double>   _resultFade;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 1000))..repeat(reverse: true);
    _resultCtrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 500));
    _pulseScale = Tween(begin: 1.0, end: 1.08).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _resultFade = CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _loadModel();
  }

  Future<void> _loadModel() async {
    try {
      await _inference.loadModel();
      setState(() => _state = AppState.ready);
    } catch (e) {
      setState(() { _state = AppState.error;
        _error = 'Model load failed:\n$e\n\nAdd model.tflite to assets/model/'; });
    }
  }

  Future<void> _startRec() async {
    if (await _recorder.startRecording() == null) {
      _snack('Microphone permission denied');
      return;
    }
    setState(() { _state = AppState.recording; _secs = 0; _result = null; });
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => _secs++);
    });
  }

  Future<void> _stopAndAnalyze() async {
    _timer?.cancel();
    setState(() => _state = AppState.analyzing);
    final samples = await _recorder.stopAndGetSamples();
    if (samples == null || samples.isEmpty) {
      setState(() { _state = AppState.error; _error = 'Recording failed'; });
      return;
    }
    try {
      final r = await _inference.predict(samples);
      await _history.save(r);
      setState(() { _state = AppState.result; _result = r; });
      _resultCtrl.forward(from: 0);
    } catch (e) {
      setState(() { _state = AppState.error; _error = e.toString(); });
    }
  }

  void _reset() {
    _resultCtrl.reset();
    setState(() { _state = AppState.ready; _result = null; _error = ''; _secs = 0; });
  }

  void _snack(String m) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(m)));

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _resultCtrl.dispose();
    _timer?.cancel();
    _recorder.dispose();
    _inference.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MahindraTheme.bgDark,
      body: CustomScrollView(
        slivers: [
          _buildAppBar(),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 32),
            sliver: SliverList(delegate: SliverChildListDelegate([
              const SizedBox(height: 8),
              _buildHeroSection(),
              const SizedBox(height: 28),
              _buildActionSection(),
              const SizedBox(height: 28),
              if (_state == AppState.result && _result != null) ...[
                _buildResultSection(),
              ],
              if (_state == AppState.error) _buildErrorCard(),
            ])),
          ),
        ],
      ),
    );
  }

  // ── App Bar ───────────────────────────────────────────────────────────────
  Widget _buildAppBar() => SliverAppBar(
    expandedHeight: 100,
    pinned: true,
    backgroundColor: MahindraTheme.bgDark,
    flexibleSpace: FlexibleSpaceBar(
      titlePadding: const EdgeInsets.fromLTRB(20, 0, 20, 14),
      title: Row(children: [
        // Mahindra logo mock (red M badge)
        Container(
          width: 32, height: 32,
          decoration: BoxDecoration(
            color: MahindraTheme.red,
            borderRadius: BorderRadius.circular(6),
          ),
          child: const Center(
            child: Text('M', style: TextStyle(color: Colors.white,
                fontSize: 18, fontWeight: FontWeight.w900)),
          ),
        ),
        const SizedBox(width: 10),
        const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('MAHINDRA', style: TextStyle(color: MahindraTheme.white,
                fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 2)),
            Text('Noise Quality Check', style: TextStyle(
                color: MahindraTheme.greyLight, fontSize: 10,
                fontWeight: FontWeight.w400, letterSpacing: 0.5)),
          ],
        ),
        const Spacer(),
        // Offline badge
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: MahindraTheme.green.withOpacity(0.15),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: MahindraTheme.green.withOpacity(0.4)),
          ),
          child: const Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.wifi_off, size: 10, color: MahindraTheme.green),
            SizedBox(width: 4),
            Text('OFFLINE', style: TextStyle(color: MahindraTheme.green,
                fontSize: 9, fontWeight: FontWeight.w700, letterSpacing: 1)),
          ]),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const HistoryScreen())),
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: MahindraTheme.bgCard,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: MahindraTheme.grey),
            ),
            child: const Icon(Icons.history, color: MahindraTheme.white, size: 18),
          ),
        ),
      ]),
    ),
  );

  // ── Hero / recording section ──────────────────────────────────────────────
  Widget _buildHeroSection() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: MahindraTheme.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: _state == AppState.recording
              ? MahindraTheme.red.withOpacity(0.6)
              : _state == AppState.result && _result != null
              ? (_result!.isOk ? MahindraTheme.green : MahindraTheme.red)
                  .withOpacity(0.4)
              : MahindraTheme.grey.withOpacity(0.5),
          width: 1.5,
        ),
      ),
      child: Column(children: [
        // Status pill
        _statusPill(),
        const SizedBox(height: 24),

        // Main visual — changes based on state
        _mainVisual(),

        const SizedBox(height: 20),

        // Recording timer or result confidence
        _centerMetric(),
      ]),
    );
  }

  Widget _statusPill() {
    String text; Color color; IconData icon;
    switch (_state) {
      case AppState.loading:
        text = 'LOADING MODEL'; color = MahindraTheme.greyLight;
        icon = Icons.hourglass_empty;
      case AppState.ready:
        text = 'READY TO SCAN'; color = MahindraTheme.green;
        icon = Icons.check_circle_outline;
      case AppState.recording:
        text = 'RECORDING AUDIO'; color = MahindraTheme.red;
        icon = Icons.fiber_manual_record;
      case AppState.analyzing:
        text = 'ANALYZING...'; color = Colors.orange;
        icon = Icons.psychology_outlined;
      case AppState.result:
        final ok = _result?.isOk ?? true;
        text = ok ? 'VEHICLE OK' : 'NOISE DETECTED';
        color = ok ? MahindraTheme.green : MahindraTheme.red;
        icon = ok ? Icons.check_circle : Icons.warning_amber_rounded;
      case AppState.error:
        text = 'ERROR'; color = MahindraTheme.red; icon = Icons.error_outline;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (_state == AppState.recording)
          _BlinkingDot(color: color)
        else
          Icon(icon, size: 14, color: color),
        const SizedBox(width: 8),
        Text(text, style: TextStyle(color: color, fontSize: 12,
            fontWeight: FontWeight.w700, letterSpacing: 1.5)),
      ]),
    );
  }

  Widget _mainVisual() {
    if (_state == AppState.loading) {
      return const SizedBox(height: 90,
          child: Center(child: CircularProgressIndicator(
              color: MahindraTheme.red, strokeWidth: 2)));
    }
    if (_state == AppState.recording) {
      return LiveWaveform(isRecording: true);
    }
    if (_state == AppState.analyzing) {
      return SizedBox(height: 90, child: Column(
        mainAxisAlignment: MainAxisAlignment.center, children: [
        const SizedBox(
          width: 36, height: 36,
          child: CircularProgressIndicator(
              color: Colors.orange, strokeWidth: 3)),
        const SizedBox(height: 12),
        Text('Running AI on device',
            style: TextStyle(color: MahindraTheme.greyLight, fontSize: 13)),
      ]));
    }
    if (_state == AppState.result && _result != null) {
      return LiveWaveform(isRecording: false);
    }
    // Ready / error — pulsing mic button
    return ScaleTransition(
      scale: _state == AppState.ready ? _pulseScale : const AlwaysStoppedAnimation(1.0),
      child: Container(
        width: 100, height: 100,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: MahindraTheme.bgCardAlt,
          border: Border.all(color: MahindraTheme.red.withOpacity(0.6), width: 2.5),
        ),
        child: const Icon(Icons.mic, size: 48, color: MahindraTheme.red),
      ),
    );
  }

  Widget _centerMetric() {
    if (_state == AppState.recording) {
      return Column(children: [
        Text('${_secs}s', style: const TextStyle(
            color: MahindraTheme.red, fontSize: 44,
            fontWeight: FontWeight.w900)),
        Text(_secs < 5 ? 'Keep recording...' : 'Good — tap Stop when ready',
            style: TextStyle(color: MahindraTheme.greyLight, fontSize: 13)),
      ]);
    }
    if (_state == AppState.result && _result != null) {
      final isOk  = _result!.isOk;
      final color = isOk ? MahindraTheme.green : MahindraTheme.red;
      return FadeTransition(
        opacity: _resultFade,
        child: Column(children: [
          Text('${(_result!.confidence * 100).toStringAsFixed(1)}%',
              style: TextStyle(color: color, fontSize: 44,
                  fontWeight: FontWeight.w900)),
          Text('confidence', style: TextStyle(
              color: MahindraTheme.greyLight, fontSize: 13)),
        ]),
      );
    }
    if (_state == AppState.ready) {
      return Text('Tap Start to begin scan',
          style: TextStyle(color: MahindraTheme.greyLight, fontSize: 14));
    }
    return const SizedBox.shrink();
  }

  // ── Action buttons ────────────────────────────────────────────────────────
  Widget _buildActionSection() {
    switch (_state) {
      case AppState.loading:
      case AppState.analyzing:
        return const SizedBox.shrink();
      case AppState.ready:
        return _bigBtn('START SCAN', Icons.mic, MahindraTheme.red, _startRec);
      case AppState.recording:
        return Row(children: [
          Expanded(child: _outlineBtn('CANCEL', Icons.close,
              MahindraTheme.greyLight, () async {
            _timer?.cancel();
            await _recorder.cancel();
            _reset();
          })),
          const SizedBox(width: 14),
          Expanded(flex: 2, child: _bigBtn(
            _secs < 3 ? 'RECORD MIN 3s...' : 'STOP & ANALYZE',
            Icons.stop_circle_outlined,
            _secs >= 3 ? MahindraTheme.red : MahindraTheme.grey,
            _secs >= 3 ? _stopAndAnalyze : null,
          )),
        ]);
      case AppState.result:
      case AppState.error:
        return _bigBtn('SCAN AGAIN', Icons.refresh, MahindraTheme.red, _reset);
    }
  }

  Widget _bigBtn(String label, IconData icon, Color color,
      VoidCallback? onTap) => SizedBox(
    height: 56, width: double.infinity,
    child: ElevatedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 20),
      label: Text(label),
      style: ElevatedButton.styleFrom(
        backgroundColor: onTap != null ? color : MahindraTheme.grey,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        elevation: 0,
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800,
            letterSpacing: 1),
      ),
    ),
  );

  Widget _outlineBtn(String label, IconData icon, Color color,
      VoidCallback? onTap) => SizedBox(
    height: 56,
    child: OutlinedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 18),
      label: Text(label),
      style: OutlinedButton.styleFrom(
        foregroundColor: color,
        side: BorderSide(color: color.withOpacity(0.5)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700,
            letterSpacing: 0.8),
      ),
    ),
  );

  // ── Result section ────────────────────────────────────────────────────────
  Widget _buildResultSection() {
    final r     = _result!;
    final isOk  = r.isOk;
    final color = isOk ? MahindraTheme.green : MahindraTheme.red;

    return FadeTransition(
      opacity: _resultFade,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

        // Verdict banner
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: color.withOpacity(0.5), width: 1.5),
          ),
          child: Row(children: [
            Container(
              width: 56, height: 56,
              decoration: BoxDecoration(
                  shape: BoxShape.circle, color: color.withOpacity(0.15)),
              child: Icon(
                isOk ? Icons.check_circle : Icons.warning_amber_rounded,
                color: color, size: 32,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(r.verdict, style: TextStyle(color: color, fontSize: 22,
                  fontWeight: FontWeight.w900)),
              Text(isOk
                  ? 'No abnormal noise detected'
                  : 'Abnormal noise found — inspect vehicle',
                  style: const TextStyle(color: MahindraTheme.greyLight,
                      fontSize: 13)),
            ])),
          ]),
        ),

        const SizedBox(height: 16),

        // Stats row
        Row(children: [
          _statCard('Confidence',
              '${(r.confidence * 100).toStringAsFixed(1)}%', color),
          const SizedBox(width: 12),
          _statCard('Noise windows',
              '${(r.notOkRatio * 100).toStringAsFixed(0)}%',
              MahindraTheme.amber),
          const SizedBox(width: 12),
          _statCard('Speech removed',
              '${r.speechPct.toStringAsFixed(1)}%', MahindraTheme.greyLight),
        ]),

        const SizedBox(height: 16),

        // Waveform snapshot
        _section(WaveformSnapshot(
            samples: r.waveformSnapshot, isNotOk: !isOk)),

        const SizedBox(height: 16),

        // Mel spectrogram
        if (r.melData != null)
          _section(MelSpectrogramView(data: r.melData!, isNotOk: !isOk)),

        const SizedBox(height: 16),

        // Window bars
        _section(WindowBarsView(probs: r.windowProbs)),

        const SizedBox(height: 16),

        // Recommendation card
        if (!isOk)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: MahindraTheme.bgCard,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: MahindraTheme.red.withOpacity(0.3)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                children: [
              const Row(children: [
                Icon(Icons.build_outlined, color: MahindraTheme.red, size: 16),
                SizedBox(width: 8),
                Text('RECOMMENDED CHECKS',
                    style: TextStyle(color: MahindraTheme.red, fontSize: 11,
                        fontWeight: FontWeight.w700, letterSpacing: 1.2)),
              ]),
              const SizedBox(height: 10),
              ...[
                'Instrument Panel (IP) fasteners and clips',
                'Steering column bearings and joints',
                'Dashboard trim and vents',
                'Door trim panels and rattles',
              ].map((s) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Container(
                    margin: const EdgeInsets.only(top: 5),
                    width: 5, height: 5,
                    decoration: const BoxDecoration(
                        color: MahindraTheme.red, shape: BoxShape.circle),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Text(s, style: const TextStyle(
                      color: MahindraTheme.greyLight, fontSize: 13))),
                ]),
              )),
            ]),
          ),
      ]),
    );
  }

  Widget _statCard(String label, String value, Color color) => Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      decoration: BoxDecoration(
        color: MahindraTheme.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: MahindraTheme.grey.withOpacity(0.5)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value, style: TextStyle(color: color,
            fontWeight: FontWeight.w800, fontSize: 18)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(
            color: MahindraTheme.greyLight, fontSize: 10)),
      ]),
    ),
  );

  Widget _section(Widget child) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: MahindraTheme.bgCard,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: MahindraTheme.grey.withOpacity(0.5)),
    ),
    child: child,
  );

  Widget _buildErrorCard() => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: MahindraTheme.red.withOpacity(0.1),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: MahindraTheme.red.withOpacity(0.4)),
    ),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Icon(Icons.error_outline, color: MahindraTheme.red),
      const SizedBox(width: 12),
      Expanded(child: Text(_error,
          style: const TextStyle(color: MahindraTheme.red, fontSize: 13))),
    ]),
  );
}

// Blinking red dot for recording indicator
class _BlinkingDot extends StatefulWidget {
  final Color color;
  const _BlinkingDot({required this.color});
  @override
  State<_BlinkingDot> createState() => _BlinkingDotState();
}

class _BlinkingDotState extends State<_BlinkingDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 600))..repeat(reverse: true);
  }
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _c,
    builder: (_, __) => Container(
      width: 8, height: 8,
      decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: widget.color.withOpacity(0.4 + _c.value * 0.6)),
    ),
  );
}
