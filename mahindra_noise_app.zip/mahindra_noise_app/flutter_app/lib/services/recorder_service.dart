// lib/services/recorder_service.dart
import 'dart:io';
import 'dart:typed_data';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:permission_handler/permission_handler.dart';

class RecorderService {
  final AudioRecorder _recorder = AudioRecorder();

  Future<bool> requestPermission() async =>
      (await Permission.microphone.request()).isGranted;

  Future<String?> startRecording() async {
    if (!await requestPermission()) return null;
    final dir  = await getTemporaryDirectory();
    final path = p.join(dir.path,
        'vehicle_${DateTime.now().millisecondsSinceEpoch}.wav');
    await _recorder.start(
      RecordConfig(encoder: AudioEncoder.wav, sampleRate: 22050,
          numChannels: 1, bitRate: 128000),
      path: path,
    );
    return path;
  }

  Future<Float32List?> stopAndGetSamples() async {
    final path = await _recorder.stop();
    if (path == null) return null;
    final file = File(path);
    if (!file.existsSync()) return null;
    final samples = _decodeWav(file.readAsBytesSync());
    file.deleteSync();
    return samples;
  }

  Future<void> cancel() => _recorder.cancel();
  void dispose() => _recorder.dispose();

  Float32List _decodeWav(Uint8List bytes) {
    const header = 44;
    if (bytes.length <= header) return Float32List(0);
    final data    = bytes.sublist(header);
    final samples = Float32List(data.length ~/ 2);
    final bd      = ByteData.view(data.buffer);
    for (int i = 0; i < samples.length; i++)
      samples[i] = bd.getInt16(i * 2, Endian.little) / 32768.0;
    return samples;
  }
}
