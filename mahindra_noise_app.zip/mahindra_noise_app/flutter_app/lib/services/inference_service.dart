// lib/services/inference_service.dart
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:tflite_flutter/tflite_flutter.dart';

class MelSpectrogramData {
  final List<List<double>> data; // (nMels, timeFrames) normalized 0-1
  final int nMels;
  final int nFrames;
  MelSpectrogramData({required this.data, required this.nMels, required this.nFrames});
}

class PredictionResult {
  final String  verdict;
  final double  confidence;
  final double  notOkRatio;
  final double  speechPct;
  final List<double> windowProbs;
  final MelSpectrogramData? melData;
  final List<double> waveformSnapshot; // downsampled for display
  final Duration audioDuration;
  final String?  error;
  final DateTime timestamp;

  PredictionResult({
    required this.verdict,
    required this.confidence,
    required this.notOkRatio,
    required this.speechPct,
    required this.windowProbs,
    this.melData,
    required this.waveformSnapshot,
    required this.audioDuration,
    this.error,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  bool get isOk      => verdict == 'OK';
  bool get isUnknown => verdict == 'UNKNOWN';

  Map<String, dynamic> toJson() => {
    'verdict':       verdict,
    'confidence':    confidence,
    'not_ok_ratio':  notOkRatio,
    'speech_pct':    speechPct,
    'window_probs':  windowProbs,
    'waveform':      waveformSnapshot,
    'duration_ms':   audioDuration.inMilliseconds,
    'timestamp':     timestamp.toIso8601String(),
  };

  factory PredictionResult.fromJson(Map<String, dynamic> j) => PredictionResult(
    verdict:    j['verdict'],
    confidence: (j['confidence'] as num).toDouble(),
    notOkRatio: (j['not_ok_ratio'] as num).toDouble(),
    speechPct:  (j['speech_pct'] as num).toDouble(),
    windowProbs: List<double>.from(
        (j['window_probs'] as List).map((v) => (v as num).toDouble())),
    waveformSnapshot: List<double>.from(
        (j['waveform'] as List? ?? []).map((v) => (v as num).toDouble())),
    audioDuration: Duration(milliseconds: (j['duration_ms'] as num?)?.toInt() ?? 0),
    timestamp: DateTime.parse(j['timestamp']),
  );
}

class InferenceService {
  Interpreter? _interpreter;
  bool _isLoaded = false;

  static const int nMels        = 128;
  static const int targetFrames = 128;
  static const int nFft         = 2048;
  static const int hopLength    = 512;
  static const int sampleRate   = 22050;
  static const double fMin      = 300.0;
  static const double fMax      = 10000.0;
  static const double inferenceThreshold = 0.50;
  static const double voteThreshold      = 0.35;
  static const double speechThresholdDb  = -20.0;
  static const double silenceThresholdDb = -50.0;
  static const double windowSkipDb       = -15.0;

  bool get isLoaded => _isLoaded;

  Future<void> loadModel() async {
    _interpreter = await Interpreter.fromAsset('assets/model/model.tflite');
    _isLoaded = true;
  }

  void dispose() { _interpreter?.close(); _isLoaded = false; }

  Future<PredictionResult> predict(Float32List audioSamples) async {
    if (!_isLoaded) throw Exception('Model not loaded');

    final duration = Duration(
        milliseconds: (audioSamples.length / sampleRate * 1000).round());

    // Downsampled waveform for display (300 points)
    final waveSnap = _downsample(audioSamples, 300);

    // Speech removal
    final cleaned   = _removeSpeech(audioSamples);
    final speechPct = cleaned.speechPercent;

    // Slice
    final windows = _sliceWindows(cleaned.audio);

    if (windows.isEmpty) {
      return PredictionResult(
        verdict: 'UNKNOWN', confidence: 0.5, notOkRatio: 0.0,
        speechPct: speechPct, windowProbs: [],
        waveformSnapshot: waveSnap, audioDuration: duration,
        error: 'No valid windows — record at least 5 seconds',
      );
    }

    // Build mel for display from first valid window
    final displayMel = _buildDisplayMel(windows.first);

    // Inference
    final probs = <double>[];
    for (final w in windows) {
      final mel  = _melSpectrogram(w);
      final prob = _runInference(mel);
      probs.add(prob);
    }

    final notOkRatio = probs.where((p) => p >= inferenceThreshold).length / probs.length;
    final meanProb   = probs.reduce((a, b) => a + b) / probs.length;
    final verdict    = notOkRatio >= voteThreshold ? 'Not-OK' : 'OK';

    return PredictionResult(
      verdict:          verdict,
      confidence:       meanProb,
      notOkRatio:       notOkRatio,
      speechPct:        speechPct,
      windowProbs:      probs,
      melData:          displayMel,
      waveformSnapshot: waveSnap,
      audioDuration:    duration,
    );
  }

  List<double> _downsample(Float32List audio, int targetLen) {
    final step = audio.length / targetLen;
    return List.generate(targetLen, (i) {
      final idx = (i * step).floor().clamp(0, audio.length - 1);
      return audio[idx].toDouble();
    });
  }

  _CleanedAudio _removeSpeech(Float32List audio) {
    const frameSamples = 441; // 20ms at 22050Hz
    final cleaned = Float32List.fromList(audio);
    int speech = 0, total = 0;
    final rng = math.Random();
    for (int i = 0; i < audio.length - frameSamples; i += frameSamples) {
      total++;
      double sum = 0;
      for (int j = i; j < i + frameSamples; j++) sum += audio[j] * audio[j];
      final db = 20 * math.log(math.sqrt(sum / frameSamples) + 1e-9) / math.ln10;
      if (db > speechThresholdDb) {
        speech++;
        for (int j = i; j < i + frameSamples; j++)
          cleaned[j] = (rng.nextDouble() - 0.5) * 0.004;
      }
    }
    return _CleanedAudio(
        audio: cleaned,
        speechPercent: total > 0 ? 100.0 * speech / total : 0.0);
  }

  List<Float32List> _sliceWindows(Float32List audio) {
    final winS  = (3.0 * sampleRate).round();
    final hopS  = (1.0 * sampleRate).round();
    final out   = <Float32List>[];
    for (int s = 0; s + winS <= audio.length; s += hopS) {
      final w = Float32List.fromList(audio.sublist(s, s + winS));
      double sum = 0;
      for (final x in w) sum += x * x;
      final db = 20 * math.log(math.sqrt(sum / w.length) + 1e-9) / math.ln10;
      if (db > windowSkipDb || db < silenceThresholdDb) continue;
      out.add(w);
    }
    return out;
  }

  MelSpectrogramData _buildDisplayMel(Float32List window) {
    final mel = _melSpectrogram(window);
    // Normalize to 0-1 for color mapping
    double minV = double.infinity, maxV = double.negativeInfinity;
    for (final row in mel) for (final v in row) {
      if (v < minV) minV = v;
      if (v > maxV) maxV = v;
    }
    final range = (maxV - minV).abs() + 1e-8;
    final norm = List.generate(nMels, (m) =>
        List.generate(targetFrames, (t) => ((mel[m][t] - minV) / range)));
    return MelSpectrogramData(data: norm, nMels: nMels, nFrames: targetFrames);
  }

  List<List<double>> _melSpectrogram(Float32List audio) {
    final hann = List.generate(nFft,
        (n) => 0.5 - 0.5 * math.cos(2 * math.pi * n / (nFft - 1)));
    final padded = Float32List(audio.length + nFft);
    for (int i = 0; i < audio.length; i++) padded[i + nFft ~/ 2] = audio[i];
    final fb = _buildFilterbank();
    final frames = <List<double>>[];
    for (int s = 0; s + nFft < padded.length; s += hopLength) {
      final frame  = List.generate(nFft, (i) => padded[s + i] * hann[i]);
      final power  = _powerSpectrum(frame);
      final melRow = List.generate(nMels, (m) {
        double v = 0;
        for (int k = 0; k < power.length; k++) v += power[k] * fb[m][k];
        return 10 * math.log(v + 1e-9) / math.ln10;
      });
      frames.add(melRow);
    }
    final t = frames.length;
    final out = List.generate(nMels, (m) => List.generate(t, (f) => frames[f][m]));
    return _padOrCrop(out);
  }

  List<List<double>> _padOrCrop(List<List<double>> mel) {
    final t = mel[0].length;
    if (t >= targetFrames) {
      final s = (t - targetFrames) ~/ 2;
      return List.generate(nMels, (m) => mel[m].sublist(s, s + targetFrames));
    }
    final pad = targetFrames - t;
    final l = pad ~/ 2, r = pad - l;
    return List.generate(nMels, (m) =>
        [...List.filled(l, 0.0), ...mel[m], ...List.filled(r, 0.0)]);
  }

  List<double> _powerSpectrum(List<double> frame) {
    final n = frame.length;
    return List.generate(n ~/ 2 + 1, (k) {
      double re = 0, im = 0;
      for (int t = 0; t < n; t++) {
        final a = 2 * math.pi * k * t / n;
        re += frame[t] * math.cos(a);
        im -= frame[t] * math.sin(a);
      }
      return re * re + im * im;
    });
  }

  List<List<double>> _buildFilterbank() {
    final melMin = 2595 * math.log(1 + fMin / 700) / math.ln10;
    final melMax = 2595 * math.log(1 + fMax / 700) / math.ln10;
    final mels   = List.generate(nMels + 2,
        (i) => melMin + i * (melMax - melMin) / (nMels + 1));
    final hz   = mels.map((m) => 700 * (math.pow(10, m / 2595) - 1)).toList();
    final bins = hz.map((h) =>
        ((nFft + 1) * h / sampleRate).floor().clamp(0, nFft ~/ 2)).toList();
    final fb = List.generate(nMels, (_) => List.filled(nFft ~/ 2 + 1, 0.0));
    for (int m = 1; m <= nMels; m++) {
      for (int k = bins[m-1]; k < bins[m]; k++)
        fb[m-1][k] = (k - bins[m-1]) / (bins[m] - bins[m-1] + 1e-8);
      for (int k = bins[m]; k < bins[m+1]; k++)
        fb[m-1][k] = (bins[m+1] - k) / (bins[m+1] - bins[m] + 1e-8);
    }
    return fb;
  }

  double _runInference(List<List<double>> mel) {
    double mean = 0, count = 0;
    for (final r in mel) for (final v in r) { mean += v; count++; }
    mean /= count;
    double var_ = 0;
    for (final r in mel) for (final v in r) var_ += (v - mean) * (v - mean);
    final std = math.sqrt(var_ / count + 1e-8);

    final input = List.generate(1, (_) => List.generate(1, (_) =>
        List.generate(nMels, (m) =>
            List.generate(targetFrames, (t) => (mel[m][t] - mean) / std))));
    final output = List.generate(1, (_) => List.filled(1, 0.0));
    _interpreter!.run(input, output);
    return 1.0 / (1.0 + math.exp(-output[0][0]));
  }
}

class _CleanedAudio {
  final Float32List audio;
  final double speechPercent;
  _CleanedAudio({required this.audio, required this.speechPercent});
}
