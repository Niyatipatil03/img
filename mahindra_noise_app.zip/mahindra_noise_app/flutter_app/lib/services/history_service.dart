// lib/services/history_service.dart
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'inference_service.dart';

class HistoryService {
  static const _key     = 'mahindra_scan_history';
  static const _maxRows = 100;

  Future<List<PredictionResult>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw   = prefs.getStringList(_key) ?? [];
    return raw
        .map((s) => PredictionResult.fromJson(jsonDecode(s)))
        .toList()
        .reversed
        .toList();
  }

  Future<void> save(PredictionResult r) async {
    final prefs = await SharedPreferences.getInstance();
    final raw   = prefs.getStringList(_key) ?? [];
    raw.add(jsonEncode(r.toJson()));
    await prefs.setStringList(_key,
        raw.length > _maxRows ? raw.sublist(raw.length - _maxRows) : raw);
  }

  Future<void> clear() async =>
      (await SharedPreferences.getInstance()).remove(_key);
}
