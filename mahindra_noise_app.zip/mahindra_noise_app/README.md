# Mahindra Vehicle Noise Quality Check — Offline Flutter App

Fully offline Android app. No WiFi, no server, no USB after install.
AI runs completely on the phone using TFLite.

---

## Features
- Live animated waveform while recording
- Mel spectrogram heatmap of the recording
- Per-window noise score bar chart
- Full scan history with filter (All / OK / Not-OK)
- Tap any past scan to see its waveform + window scores
- Summary stats: total scans, pass rate
- Recommended checks list when noise is detected
- Mahindra red/white theme

---

## Setup (3 steps)

### Step 1 — Convert model (PC, one time)
```bash
pip install onnx onnx-tf tensorflow
cd vehicle_noise_detector
python converter/convert_to_tflite.py
```
Automatically places `model.tflite` in `flutter_app/assets/model/`

### Step 2 — Build APK
```bash
cd flutter_app
flutter pub get
flutter build apk --release
```
APK: `flutter_app/build/app/outputs/flutter-apk/app-release.apk`

### Step 3 — Install
Copy APK to phone → open to install
(Settings → Security → Allow from unknown sources if prompted)

---

## How to use
1. Open app → tap **START SCAN**
2. Hold phone inside vehicle near dashboard, engine running
3. Record 5–10 seconds
4. Tap **STOP & ANALYZE**
5. View verdict + waveform + mel spectrogram
6. Tap **History** icon to review past scans
