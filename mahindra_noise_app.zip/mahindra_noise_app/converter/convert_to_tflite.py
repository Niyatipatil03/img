# converter/convert_to_tflite.py
# Run this ONCE after training to convert PyTorch model → TFLite
#
# pip install onnx onnx-tf tensorflow
# python converter/convert_to_tflite.py

import os, sys, numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
from src.model import VehicleNoiseNet
from config import MODELS_DIR, N_MELS, TARGET_FRAMES

OUT = os.path.join(os.path.dirname(__file__), '..', 'flutter_app', 'assets', 'model')
os.makedirs(OUT, exist_ok=True)
ONNX   = os.path.join(OUT, 'model.onnx')
TFLITE = os.path.join(OUT, 'model.tflite')

def main():
    print("=" * 50)
    print("  PyTorch → TFLite Converter")
    print("=" * 50)

    # Load
    path = os.path.join(MODELS_DIR, 'best_model.pt')
    if not os.path.exists(path):
        print(f"\n  ERROR: No model at {path}. Run train.py first.")
        return
    model = VehicleNoiseNet()
    ckpt  = torch.load(path, map_location='cpu')
    model.load_state_dict(ckpt['model_state'])
    model.eval()
    print(f"  Loaded — val_f1: {ckpt.get('val_f1', 0):.4f}")

    # ONNX export
    print("\n  Exporting to ONNX...")
    dummy = torch.randn(1, 1, N_MELS, TARGET_FRAMES)
    torch.onnx.export(model, dummy, ONNX,
        input_names=['input'], output_names=['logit'],
        opset_version=12, do_constant_folding=True)
    print(f"  ONNX → {ONNX}")

    # TFLite conversion
    print("\n  Converting to TFLite...")
    import onnx
    from onnx_tf.backend import prepare
    import tensorflow as tf

    tf_rep = prepare(onnx.load(ONNX))
    saved  = ONNX.replace('.onnx', '_saved')
    tf_rep.export_graph(saved)

    conv = tf.lite.TFLiteConverter.from_saved_model(saved)
    conv.optimizations = [tf.lite.Optimize.DEFAULT]
    conv.target_spec.supported_types = [tf.float16]
    tflite = conv.convert()

    with open(TFLITE, 'wb') as f: f.write(tflite)
    print(f"  TFLite → {TFLITE}  ({os.path.getsize(TFLITE)//1024} KB)")

    # Verify
    interp = tf.lite.Interpreter(model_path=TFLITE)
    interp.allocate_tensors()
    inp = interp.get_input_details()[0]
    out = interp.get_output_details()[0]
    interp.set_tensor(inp['index'],
        np.random.randn(1, 1, N_MELS, TARGET_FRAMES).astype(np.float32))
    interp.invoke()
    logit = interp.get_tensor(out['index'])[0][0]
    print(f"  Test inference: prob={1/(1+np.exp(-logit)):.4f}  OK")
    print(f"\n  Done! model.tflite is ready in flutter_app/assets/model/")
    print("  Now run: cd flutter_app && flutter build apk --release")

if __name__ == '__main__':
    main()
